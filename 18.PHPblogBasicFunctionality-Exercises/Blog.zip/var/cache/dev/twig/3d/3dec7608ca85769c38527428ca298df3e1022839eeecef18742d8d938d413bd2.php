<?php

/* bootstrap_3_layout.html.twig */
class __TwigTemplate_5839cbc8ddff9a564a036e42018148a480ab99f459d68f04c3640957892b8bba extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $_trait_0 = $this->loadTemplate("form_div_layout.html.twig", "bootstrap_3_layout.html.twig", 1);
        // line 1
        if (!$_trait_0->isTraitable()) {
            throw new Twig_Error_Runtime('Template "'."form_div_layout.html.twig".'" cannot be used as a trait.');
        }
        $_trait_0_blocks = $_trait_0->getBlocks();

        $this->traits = $_trait_0_blocks;

        $this->blocks = array_merge(
            $this->traits,
            array(
                'form_widget_simple' => array($this, 'block_form_widget_simple'),
                'textarea_widget' => array($this, 'block_textarea_widget'),
                'button_widget' => array($this, 'block_button_widget'),
                'money_widget' => array($this, 'block_money_widget'),
                'percent_widget' => array($this, 'block_percent_widget'),
                'datetime_widget' => array($this, 'block_datetime_widget'),
                'date_widget' => array($this, 'block_date_widget'),
                'time_widget' => array($this, 'block_time_widget'),
                'dateinterval_widget' => array($this, 'block_dateinterval_widget'),
                'choice_widget_collapsed' => array($this, 'block_choice_widget_collapsed'),
                'choice_widget_expanded' => array($this, 'block_choice_widget_expanded'),
                'checkbox_widget' => array($this, 'block_checkbox_widget'),
                'radio_widget' => array($this, 'block_radio_widget'),
                'form_label' => array($this, 'block_form_label'),
                'choice_label' => array($this, 'block_choice_label'),
                'checkbox_label' => array($this, 'block_checkbox_label'),
                'radio_label' => array($this, 'block_radio_label'),
                'checkbox_radio_label' => array($this, 'block_checkbox_radio_label'),
                'form_row' => array($this, 'block_form_row'),
                'button_row' => array($this, 'block_button_row'),
                'choice_row' => array($this, 'block_choice_row'),
                'date_row' => array($this, 'block_date_row'),
                'time_row' => array($this, 'block_time_row'),
                'datetime_row' => array($this, 'block_datetime_row'),
                'checkbox_row' => array($this, 'block_checkbox_row'),
                'radio_row' => array($this, 'block_radio_row'),
                'form_errors' => array($this, 'block_form_errors'),
            )
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_25bf75f3020acc9150fc933236d00851048dd53f7c6260e1c0d27df461ebb610 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_25bf75f3020acc9150fc933236d00851048dd53f7c6260e1c0d27df461ebb610->enter($__internal_25bf75f3020acc9150fc933236d00851048dd53f7c6260e1c0d27df461ebb610_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "bootstrap_3_layout.html.twig"));

        $__internal_2e7fbfc8010692bd537ee7c9e8a2cc3c3355bc7d8e9191a2123f3ed55ad97ee3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2e7fbfc8010692bd537ee7c9e8a2cc3c3355bc7d8e9191a2123f3ed55ad97ee3->enter($__internal_2e7fbfc8010692bd537ee7c9e8a2cc3c3355bc7d8e9191a2123f3ed55ad97ee3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "bootstrap_3_layout.html.twig"));

        // line 2
        echo "
";
        // line 4
        echo "
";
        // line 5
        $this->displayBlock('form_widget_simple', $context, $blocks);
        // line 11
        echo "
";
        // line 12
        $this->displayBlock('textarea_widget', $context, $blocks);
        // line 16
        echo "
";
        // line 17
        $this->displayBlock('button_widget', $context, $blocks);
        // line 21
        echo "
";
        // line 22
        $this->displayBlock('money_widget', $context, $blocks);
        // line 34
        echo "
";
        // line 35
        $this->displayBlock('percent_widget', $context, $blocks);
        // line 41
        echo "
";
        // line 42
        $this->displayBlock('datetime_widget', $context, $blocks);
        // line 55
        echo "
";
        // line 56
        $this->displayBlock('date_widget', $context, $blocks);
        // line 74
        echo "
";
        // line 75
        $this->displayBlock('time_widget', $context, $blocks);
        // line 90
        $this->displayBlock('dateinterval_widget', $context, $blocks);
        // line 128
        $this->displayBlock('choice_widget_collapsed', $context, $blocks);
        // line 132
        echo "
";
        // line 133
        $this->displayBlock('choice_widget_expanded', $context, $blocks);
        // line 152
        echo "
";
        // line 153
        $this->displayBlock('checkbox_widget', $context, $blocks);
        // line 163
        echo "
";
        // line 164
        $this->displayBlock('radio_widget', $context, $blocks);
        // line 174
        echo "
";
        // line 176
        echo "
";
        // line 177
        $this->displayBlock('form_label', $context, $blocks);
        // line 181
        echo "
";
        // line 182
        $this->displayBlock('choice_label', $context, $blocks);
        // line 187
        echo "
";
        // line 188
        $this->displayBlock('checkbox_label', $context, $blocks);
        // line 193
        echo "
";
        // line 194
        $this->displayBlock('radio_label', $context, $blocks);
        // line 199
        echo "
";
        // line 200
        $this->displayBlock('checkbox_radio_label', $context, $blocks);
        // line 224
        echo "
";
        // line 226
        echo "
";
        // line 227
        $this->displayBlock('form_row', $context, $blocks);
        // line 234
        echo "
";
        // line 235
        $this->displayBlock('button_row', $context, $blocks);
        // line 240
        echo "
";
        // line 241
        $this->displayBlock('choice_row', $context, $blocks);
        // line 245
        echo "
";
        // line 246
        $this->displayBlock('date_row', $context, $blocks);
        // line 250
        echo "
";
        // line 251
        $this->displayBlock('time_row', $context, $blocks);
        // line 255
        echo "
";
        // line 256
        $this->displayBlock('datetime_row', $context, $blocks);
        // line 260
        echo "
";
        // line 261
        $this->displayBlock('checkbox_row', $context, $blocks);
        // line 267
        echo "
";
        // line 268
        $this->displayBlock('radio_row', $context, $blocks);
        // line 274
        echo "
";
        // line 276
        echo "
";
        // line 277
        $this->displayBlock('form_errors', $context, $blocks);
        
        $__internal_25bf75f3020acc9150fc933236d00851048dd53f7c6260e1c0d27df461ebb610->leave($__internal_25bf75f3020acc9150fc933236d00851048dd53f7c6260e1c0d27df461ebb610_prof);

        
        $__internal_2e7fbfc8010692bd537ee7c9e8a2cc3c3355bc7d8e9191a2123f3ed55ad97ee3->leave($__internal_2e7fbfc8010692bd537ee7c9e8a2cc3c3355bc7d8e9191a2123f3ed55ad97ee3_prof);

    }

    // line 5
    public function block_form_widget_simple($context, array $blocks = array())
    {
        $__internal_b7bb0122cf0102bd55717e41ec2e20d6c14a6337b22e966969013935aa9851bb = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b7bb0122cf0102bd55717e41ec2e20d6c14a6337b22e966969013935aa9851bb->enter($__internal_b7bb0122cf0102bd55717e41ec2e20d6c14a6337b22e966969013935aa9851bb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_widget_simple"));

        $__internal_25ce9cab6cd65c052ee6dc77751187604ff468e83d1d67e60b1aae3714f382a9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_25ce9cab6cd65c052ee6dc77751187604ff468e83d1d67e60b1aae3714f382a9->enter($__internal_25ce9cab6cd65c052ee6dc77751187604ff468e83d1d67e60b1aae3714f382a9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_widget_simple"));

        // line 6
        if (( !array_key_exists("type", $context) || !twig_in_filter(($context["type"] ?? $this->getContext($context, "type")), array(0 => "file", 1 => "hidden")))) {
            // line 7
            $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "")) : ("")) . " form-control"))));
        }
        // line 9
        $this->displayParentBlock("form_widget_simple", $context, $blocks);
        
        $__internal_25ce9cab6cd65c052ee6dc77751187604ff468e83d1d67e60b1aae3714f382a9->leave($__internal_25ce9cab6cd65c052ee6dc77751187604ff468e83d1d67e60b1aae3714f382a9_prof);

        
        $__internal_b7bb0122cf0102bd55717e41ec2e20d6c14a6337b22e966969013935aa9851bb->leave($__internal_b7bb0122cf0102bd55717e41ec2e20d6c14a6337b22e966969013935aa9851bb_prof);

    }

    // line 12
    public function block_textarea_widget($context, array $blocks = array())
    {
        $__internal_d93c39efbf8e0ca0ecab8ab683d3075fb7a510edd1cf266fbee08a387292c7ad = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d93c39efbf8e0ca0ecab8ab683d3075fb7a510edd1cf266fbee08a387292c7ad->enter($__internal_d93c39efbf8e0ca0ecab8ab683d3075fb7a510edd1cf266fbee08a387292c7ad_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "textarea_widget"));

        $__internal_2ab9feaaf55789a023872f16506e3058e4ca7c47764186e9b7231bb3005b8f89 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2ab9feaaf55789a023872f16506e3058e4ca7c47764186e9b7231bb3005b8f89->enter($__internal_2ab9feaaf55789a023872f16506e3058e4ca7c47764186e9b7231bb3005b8f89_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "textarea_widget"));

        // line 13
        $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "")) : ("")) . " form-control"))));
        // line 14
        $this->displayParentBlock("textarea_widget", $context, $blocks);
        
        $__internal_2ab9feaaf55789a023872f16506e3058e4ca7c47764186e9b7231bb3005b8f89->leave($__internal_2ab9feaaf55789a023872f16506e3058e4ca7c47764186e9b7231bb3005b8f89_prof);

        
        $__internal_d93c39efbf8e0ca0ecab8ab683d3075fb7a510edd1cf266fbee08a387292c7ad->leave($__internal_d93c39efbf8e0ca0ecab8ab683d3075fb7a510edd1cf266fbee08a387292c7ad_prof);

    }

    // line 17
    public function block_button_widget($context, array $blocks = array())
    {
        $__internal_a9ca5250c880eb2f49a774d9a6c78438441565c24d4f68b8ec7bb28c9f0b89b2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a9ca5250c880eb2f49a774d9a6c78438441565c24d4f68b8ec7bb28c9f0b89b2->enter($__internal_a9ca5250c880eb2f49a774d9a6c78438441565c24d4f68b8ec7bb28c9f0b89b2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "button_widget"));

        $__internal_655d1035ba3424b8c673d95f5c3bcab8cc406e3a68c349c7bf94402159d1f2a0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_655d1035ba3424b8c673d95f5c3bcab8cc406e3a68c349c7bf94402159d1f2a0->enter($__internal_655d1035ba3424b8c673d95f5c3bcab8cc406e3a68c349c7bf94402159d1f2a0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "button_widget"));

        // line 18
        $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "btn-default")) : ("btn-default")) . " btn"))));
        // line 19
        $this->displayParentBlock("button_widget", $context, $blocks);
        
        $__internal_655d1035ba3424b8c673d95f5c3bcab8cc406e3a68c349c7bf94402159d1f2a0->leave($__internal_655d1035ba3424b8c673d95f5c3bcab8cc406e3a68c349c7bf94402159d1f2a0_prof);

        
        $__internal_a9ca5250c880eb2f49a774d9a6c78438441565c24d4f68b8ec7bb28c9f0b89b2->leave($__internal_a9ca5250c880eb2f49a774d9a6c78438441565c24d4f68b8ec7bb28c9f0b89b2_prof);

    }

    // line 22
    public function block_money_widget($context, array $blocks = array())
    {
        $__internal_06c6156c6fbc340d24f3c62993be91622906b6291301edab188019a046a252d9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_06c6156c6fbc340d24f3c62993be91622906b6291301edab188019a046a252d9->enter($__internal_06c6156c6fbc340d24f3c62993be91622906b6291301edab188019a046a252d9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "money_widget"));

        $__internal_a5180ff8e4314be1607230114bf21bafceb00be1bbe338e3ae73d41a081f2858 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a5180ff8e4314be1607230114bf21bafceb00be1bbe338e3ae73d41a081f2858->enter($__internal_a5180ff8e4314be1607230114bf21bafceb00be1bbe338e3ae73d41a081f2858_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "money_widget"));

        // line 23
        echo "<div class=\"input-group\">
        ";
        // line 24
        $context["append"] = (is_string($__internal_e3f17f29ac40f8a9ab44506109dce0951deae3b75b254fd75ad994c54dba5070 = ($context["money_pattern"] ?? $this->getContext($context, "money_pattern"))) && is_string($__internal_6977c164270e623ec52d806dd174a6c581ab57357011a3d4d5cee22283c9fb7c = "{{") && ('' === $__internal_6977c164270e623ec52d806dd174a6c581ab57357011a3d4d5cee22283c9fb7c || 0 === strpos($__internal_e3f17f29ac40f8a9ab44506109dce0951deae3b75b254fd75ad994c54dba5070, $__internal_6977c164270e623ec52d806dd174a6c581ab57357011a3d4d5cee22283c9fb7c)));
        // line 25
        echo "        ";
        if ( !($context["append"] ?? $this->getContext($context, "append"))) {
            // line 26
            echo "            <span class=\"input-group-addon\">";
            echo twig_escape_filter($this->env, twig_replace_filter(($context["money_pattern"] ?? $this->getContext($context, "money_pattern")), array("{{ widget }}" => "")), "html", null, true);
            echo "</span>
        ";
        }
        // line 28
        $this->displayBlock("form_widget_simple", $context, $blocks);
        // line 29
        if (($context["append"] ?? $this->getContext($context, "append"))) {
            // line 30
            echo "            <span class=\"input-group-addon\">";
            echo twig_escape_filter($this->env, twig_replace_filter(($context["money_pattern"] ?? $this->getContext($context, "money_pattern")), array("{{ widget }}" => "")), "html", null, true);
            echo "</span>
        ";
        }
        // line 32
        echo "    </div>";
        
        $__internal_a5180ff8e4314be1607230114bf21bafceb00be1bbe338e3ae73d41a081f2858->leave($__internal_a5180ff8e4314be1607230114bf21bafceb00be1bbe338e3ae73d41a081f2858_prof);

        
        $__internal_06c6156c6fbc340d24f3c62993be91622906b6291301edab188019a046a252d9->leave($__internal_06c6156c6fbc340d24f3c62993be91622906b6291301edab188019a046a252d9_prof);

    }

    // line 35
    public function block_percent_widget($context, array $blocks = array())
    {
        $__internal_59b60f9f1b17dc0b6da221039a1e0705108cbaaea7b6984893eeef643b48e91d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_59b60f9f1b17dc0b6da221039a1e0705108cbaaea7b6984893eeef643b48e91d->enter($__internal_59b60f9f1b17dc0b6da221039a1e0705108cbaaea7b6984893eeef643b48e91d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "percent_widget"));

        $__internal_fbadde568469156150f4a9f28634944077249b88c8022a2d79946d66d13ba4b6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fbadde568469156150f4a9f28634944077249b88c8022a2d79946d66d13ba4b6->enter($__internal_fbadde568469156150f4a9f28634944077249b88c8022a2d79946d66d13ba4b6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "percent_widget"));

        // line 36
        echo "<div class=\"input-group\">";
        // line 37
        $this->displayBlock("form_widget_simple", $context, $blocks);
        // line 38
        echo "<span class=\"input-group-addon\">%</span>
    </div>";
        
        $__internal_fbadde568469156150f4a9f28634944077249b88c8022a2d79946d66d13ba4b6->leave($__internal_fbadde568469156150f4a9f28634944077249b88c8022a2d79946d66d13ba4b6_prof);

        
        $__internal_59b60f9f1b17dc0b6da221039a1e0705108cbaaea7b6984893eeef643b48e91d->leave($__internal_59b60f9f1b17dc0b6da221039a1e0705108cbaaea7b6984893eeef643b48e91d_prof);

    }

    // line 42
    public function block_datetime_widget($context, array $blocks = array())
    {
        $__internal_3299b39f102ca3e52afbf81dcb55f59b129a333ce09469a99ca0aadb80a79585 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3299b39f102ca3e52afbf81dcb55f59b129a333ce09469a99ca0aadb80a79585->enter($__internal_3299b39f102ca3e52afbf81dcb55f59b129a333ce09469a99ca0aadb80a79585_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datetime_widget"));

        $__internal_55b94df7f32aa3557a2ac3acc88f6ca768f307b3b2e2058d2d55999908e0a7d9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_55b94df7f32aa3557a2ac3acc88f6ca768f307b3b2e2058d2d55999908e0a7d9->enter($__internal_55b94df7f32aa3557a2ac3acc88f6ca768f307b3b2e2058d2d55999908e0a7d9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datetime_widget"));

        // line 43
        if ((($context["widget"] ?? $this->getContext($context, "widget")) == "single_text")) {
            // line 44
            $this->displayBlock("form_widget_simple", $context, $blocks);
        } else {
            // line 46
            $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "")) : ("")) . " form-inline"))));
            // line 47
            echo "<div ";
            $this->displayBlock("widget_container_attributes", $context, $blocks);
            echo ">";
            // line 48
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "date", array()), 'errors');
            // line 49
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "time", array()), 'errors');
            // line 50
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "date", array()), 'widget', array("datetime" => true));
            // line 51
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "time", array()), 'widget', array("datetime" => true));
            // line 52
            echo "</div>";
        }
        
        $__internal_55b94df7f32aa3557a2ac3acc88f6ca768f307b3b2e2058d2d55999908e0a7d9->leave($__internal_55b94df7f32aa3557a2ac3acc88f6ca768f307b3b2e2058d2d55999908e0a7d9_prof);

        
        $__internal_3299b39f102ca3e52afbf81dcb55f59b129a333ce09469a99ca0aadb80a79585->leave($__internal_3299b39f102ca3e52afbf81dcb55f59b129a333ce09469a99ca0aadb80a79585_prof);

    }

    // line 56
    public function block_date_widget($context, array $blocks = array())
    {
        $__internal_f14b78af128ccfd94fbb9bbdf970cf9ded3aab7b8844e2a7a455442812090a6a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f14b78af128ccfd94fbb9bbdf970cf9ded3aab7b8844e2a7a455442812090a6a->enter($__internal_f14b78af128ccfd94fbb9bbdf970cf9ded3aab7b8844e2a7a455442812090a6a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "date_widget"));

        $__internal_5c11ddabbd587f293f441be5751b941b99658da779ef19735ef2fe0e8501e86a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5c11ddabbd587f293f441be5751b941b99658da779ef19735ef2fe0e8501e86a->enter($__internal_5c11ddabbd587f293f441be5751b941b99658da779ef19735ef2fe0e8501e86a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "date_widget"));

        // line 57
        if ((($context["widget"] ?? $this->getContext($context, "widget")) == "single_text")) {
            // line 58
            $this->displayBlock("form_widget_simple", $context, $blocks);
        } else {
            // line 60
            $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "")) : ("")) . " form-inline"))));
            // line 61
            if (( !array_key_exists("datetime", $context) ||  !($context["datetime"] ?? $this->getContext($context, "datetime")))) {
                // line 62
                echo "<div ";
                $this->displayBlock("widget_container_attributes", $context, $blocks);
                echo ">";
            }
            // line 64
            echo twig_replace_filter(($context["date_pattern"] ?? $this->getContext($context, "date_pattern")), array("{{ year }}" =>             // line 65
$this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "year", array()), 'widget'), "{{ month }}" =>             // line 66
$this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "month", array()), 'widget'), "{{ day }}" =>             // line 67
$this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "day", array()), 'widget')));
            // line 69
            if (( !array_key_exists("datetime", $context) ||  !($context["datetime"] ?? $this->getContext($context, "datetime")))) {
                // line 70
                echo "</div>";
            }
        }
        
        $__internal_5c11ddabbd587f293f441be5751b941b99658da779ef19735ef2fe0e8501e86a->leave($__internal_5c11ddabbd587f293f441be5751b941b99658da779ef19735ef2fe0e8501e86a_prof);

        
        $__internal_f14b78af128ccfd94fbb9bbdf970cf9ded3aab7b8844e2a7a455442812090a6a->leave($__internal_f14b78af128ccfd94fbb9bbdf970cf9ded3aab7b8844e2a7a455442812090a6a_prof);

    }

    // line 75
    public function block_time_widget($context, array $blocks = array())
    {
        $__internal_a69b292e02d7bebe341b8fbb83aa1cc29bd2f9aba7b8314b801b001ebfb5b410 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a69b292e02d7bebe341b8fbb83aa1cc29bd2f9aba7b8314b801b001ebfb5b410->enter($__internal_a69b292e02d7bebe341b8fbb83aa1cc29bd2f9aba7b8314b801b001ebfb5b410_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "time_widget"));

        $__internal_b354cecee69c19f044707306d9093d97a7d2e7b37afdc7d05220a27e8c37ab7f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b354cecee69c19f044707306d9093d97a7d2e7b37afdc7d05220a27e8c37ab7f->enter($__internal_b354cecee69c19f044707306d9093d97a7d2e7b37afdc7d05220a27e8c37ab7f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "time_widget"));

        // line 76
        if ((($context["widget"] ?? $this->getContext($context, "widget")) == "single_text")) {
            // line 77
            $this->displayBlock("form_widget_simple", $context, $blocks);
        } else {
            // line 79
            $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "")) : ("")) . " form-inline"))));
            // line 80
            if (( !array_key_exists("datetime", $context) || (false == ($context["datetime"] ?? $this->getContext($context, "datetime"))))) {
                // line 81
                echo "<div ";
                $this->displayBlock("widget_container_attributes", $context, $blocks);
                echo ">";
            }
            // line 83
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "hour", array()), 'widget');
            if (($context["with_minutes"] ?? $this->getContext($context, "with_minutes"))) {
                echo ":";
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "minute", array()), 'widget');
            }
            if (($context["with_seconds"] ?? $this->getContext($context, "with_seconds"))) {
                echo ":";
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "second", array()), 'widget');
            }
            // line 84
            echo "        ";
            if (( !array_key_exists("datetime", $context) || (false == ($context["datetime"] ?? $this->getContext($context, "datetime"))))) {
                // line 85
                echo "</div>";
            }
        }
        
        $__internal_b354cecee69c19f044707306d9093d97a7d2e7b37afdc7d05220a27e8c37ab7f->leave($__internal_b354cecee69c19f044707306d9093d97a7d2e7b37afdc7d05220a27e8c37ab7f_prof);

        
        $__internal_a69b292e02d7bebe341b8fbb83aa1cc29bd2f9aba7b8314b801b001ebfb5b410->leave($__internal_a69b292e02d7bebe341b8fbb83aa1cc29bd2f9aba7b8314b801b001ebfb5b410_prof);

    }

    // line 90
    public function block_dateinterval_widget($context, array $blocks = array())
    {
        $__internal_d86408193d0fae1c2b1f3f240ac80be4d8bcff4b48b791db6527570c32ab31a9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d86408193d0fae1c2b1f3f240ac80be4d8bcff4b48b791db6527570c32ab31a9->enter($__internal_d86408193d0fae1c2b1f3f240ac80be4d8bcff4b48b791db6527570c32ab31a9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "dateinterval_widget"));

        $__internal_a394f2dc913fcdb87bd650827d2e033ccd264d3faf8ac46e2773654a07e70ad1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a394f2dc913fcdb87bd650827d2e033ccd264d3faf8ac46e2773654a07e70ad1->enter($__internal_a394f2dc913fcdb87bd650827d2e033ccd264d3faf8ac46e2773654a07e70ad1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "dateinterval_widget"));

        // line 91
        if ((($context["widget"] ?? $this->getContext($context, "widget")) == "single_text")) {
            // line 92
            $this->displayBlock("form_widget_simple", $context, $blocks);
        } else {
            // line 94
            $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "")) : ("")) . " form-inline"))));
            // line 95
            echo "<div ";
            $this->displayBlock("widget_container_attributes", $context, $blocks);
            echo ">";
            // line 96
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'errors');
            // line 97
            echo "<div class=\"table-responsive\">
                <table class=\"table ";
            // line 98
            echo twig_escape_filter($this->env, ((array_key_exists("table_class", $context)) ? (_twig_default_filter(($context["table_class"] ?? $this->getContext($context, "table_class")), "table-bordered table-condensed table-striped")) : ("table-bordered table-condensed table-striped")), "html", null, true);
            echo "\">
                    <thead>
                    <tr>";
            // line 101
            if (($context["with_years"] ?? $this->getContext($context, "with_years"))) {
                echo "<th>";
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "years", array()), 'label');
                echo "</th>";
            }
            // line 102
            if (($context["with_months"] ?? $this->getContext($context, "with_months"))) {
                echo "<th>";
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "months", array()), 'label');
                echo "</th>";
            }
            // line 103
            if (($context["with_weeks"] ?? $this->getContext($context, "with_weeks"))) {
                echo "<th>";
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "weeks", array()), 'label');
                echo "</th>";
            }
            // line 104
            if (($context["with_days"] ?? $this->getContext($context, "with_days"))) {
                echo "<th>";
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "days", array()), 'label');
                echo "</th>";
            }
            // line 105
            if (($context["with_hours"] ?? $this->getContext($context, "with_hours"))) {
                echo "<th>";
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "hours", array()), 'label');
                echo "</th>";
            }
            // line 106
            if (($context["with_minutes"] ?? $this->getContext($context, "with_minutes"))) {
                echo "<th>";
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "minutes", array()), 'label');
                echo "</th>";
            }
            // line 107
            if (($context["with_seconds"] ?? $this->getContext($context, "with_seconds"))) {
                echo "<th>";
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "seconds", array()), 'label');
                echo "</th>";
            }
            // line 108
            echo "</tr>
                    </thead>
                    <tbody>
                    <tr>";
            // line 112
            if (($context["with_years"] ?? $this->getContext($context, "with_years"))) {
                echo "<td>";
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "years", array()), 'widget');
                echo "</td>";
            }
            // line 113
            if (($context["with_months"] ?? $this->getContext($context, "with_months"))) {
                echo "<td>";
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "months", array()), 'widget');
                echo "</td>";
            }
            // line 114
            if (($context["with_weeks"] ?? $this->getContext($context, "with_weeks"))) {
                echo "<td>";
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "weeks", array()), 'widget');
                echo "</td>";
            }
            // line 115
            if (($context["with_days"] ?? $this->getContext($context, "with_days"))) {
                echo "<td>";
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "days", array()), 'widget');
                echo "</td>";
            }
            // line 116
            if (($context["with_hours"] ?? $this->getContext($context, "with_hours"))) {
                echo "<td>";
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "hours", array()), 'widget');
                echo "</td>";
            }
            // line 117
            if (($context["with_minutes"] ?? $this->getContext($context, "with_minutes"))) {
                echo "<td>";
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "minutes", array()), 'widget');
                echo "</td>";
            }
            // line 118
            if (($context["with_seconds"] ?? $this->getContext($context, "with_seconds"))) {
                echo "<td>";
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "seconds", array()), 'widget');
                echo "</td>";
            }
            // line 119
            echo "</tr>
                    </tbody>
                </table>
            </div>";
            // line 123
            if (($context["with_invert"] ?? $this->getContext($context, "with_invert"))) {
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "invert", array()), 'widget');
            }
            // line 124
            echo "</div>";
        }
        
        $__internal_a394f2dc913fcdb87bd650827d2e033ccd264d3faf8ac46e2773654a07e70ad1->leave($__internal_a394f2dc913fcdb87bd650827d2e033ccd264d3faf8ac46e2773654a07e70ad1_prof);

        
        $__internal_d86408193d0fae1c2b1f3f240ac80be4d8bcff4b48b791db6527570c32ab31a9->leave($__internal_d86408193d0fae1c2b1f3f240ac80be4d8bcff4b48b791db6527570c32ab31a9_prof);

    }

    // line 128
    public function block_choice_widget_collapsed($context, array $blocks = array())
    {
        $__internal_533b90d345ad4c5882b89c122d7b756836b60874020f2d7297bc21c7d363ff97 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_533b90d345ad4c5882b89c122d7b756836b60874020f2d7297bc21c7d363ff97->enter($__internal_533b90d345ad4c5882b89c122d7b756836b60874020f2d7297bc21c7d363ff97_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "choice_widget_collapsed"));

        $__internal_018a59f750298c92e04cb9264945bd71b183926a7e625acb2aa53488c9eb282a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_018a59f750298c92e04cb9264945bd71b183926a7e625acb2aa53488c9eb282a->enter($__internal_018a59f750298c92e04cb9264945bd71b183926a7e625acb2aa53488c9eb282a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "choice_widget_collapsed"));

        // line 129
        $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "")) : ("")) . " form-control"))));
        // line 130
        $this->displayParentBlock("choice_widget_collapsed", $context, $blocks);
        
        $__internal_018a59f750298c92e04cb9264945bd71b183926a7e625acb2aa53488c9eb282a->leave($__internal_018a59f750298c92e04cb9264945bd71b183926a7e625acb2aa53488c9eb282a_prof);

        
        $__internal_533b90d345ad4c5882b89c122d7b756836b60874020f2d7297bc21c7d363ff97->leave($__internal_533b90d345ad4c5882b89c122d7b756836b60874020f2d7297bc21c7d363ff97_prof);

    }

    // line 133
    public function block_choice_widget_expanded($context, array $blocks = array())
    {
        $__internal_093965466342797f6b5c3de424bee779afe3a2cdf3aa9dea4473974b6f2c61cb = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_093965466342797f6b5c3de424bee779afe3a2cdf3aa9dea4473974b6f2c61cb->enter($__internal_093965466342797f6b5c3de424bee779afe3a2cdf3aa9dea4473974b6f2c61cb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "choice_widget_expanded"));

        $__internal_05b892ba2c77db355e9b46cd27cb37cc0877f6f184509bf2a54b27da35e5563f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_05b892ba2c77db355e9b46cd27cb37cc0877f6f184509bf2a54b27da35e5563f->enter($__internal_05b892ba2c77db355e9b46cd27cb37cc0877f6f184509bf2a54b27da35e5563f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "choice_widget_expanded"));

        // line 134
        if (twig_in_filter("-inline", (($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")))) {
            // line 135
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["form"] ?? $this->getContext($context, "form")));
            foreach ($context['_seq'] as $context["_key"] => $context["child"]) {
                // line 136
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($context["child"], 'widget', array("parent_label_class" => (($this->getAttribute(                // line 137
($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")), "translation_domain" =>                 // line 138
($context["choice_translation_domain"] ?? $this->getContext($context, "choice_translation_domain"))));
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['child'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
        } else {
            // line 142
            echo "<div ";
            $this->displayBlock("widget_container_attributes", $context, $blocks);
            echo ">";
            // line 143
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["form"] ?? $this->getContext($context, "form")));
            foreach ($context['_seq'] as $context["_key"] => $context["child"]) {
                // line 144
                echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($context["child"], 'widget', array("parent_label_class" => (($this->getAttribute(                // line 145
($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")), "translation_domain" =>                 // line 146
($context["choice_translation_domain"] ?? $this->getContext($context, "choice_translation_domain"))));
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['child'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 149
            echo "</div>";
        }
        
        $__internal_05b892ba2c77db355e9b46cd27cb37cc0877f6f184509bf2a54b27da35e5563f->leave($__internal_05b892ba2c77db355e9b46cd27cb37cc0877f6f184509bf2a54b27da35e5563f_prof);

        
        $__internal_093965466342797f6b5c3de424bee779afe3a2cdf3aa9dea4473974b6f2c61cb->leave($__internal_093965466342797f6b5c3de424bee779afe3a2cdf3aa9dea4473974b6f2c61cb_prof);

    }

    // line 153
    public function block_checkbox_widget($context, array $blocks = array())
    {
        $__internal_19a4909551a253bcec38acc800eb1672e06503564af5a6fed0b84538be95fcf2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_19a4909551a253bcec38acc800eb1672e06503564af5a6fed0b84538be95fcf2->enter($__internal_19a4909551a253bcec38acc800eb1672e06503564af5a6fed0b84538be95fcf2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "checkbox_widget"));

        $__internal_861935fa55e72f85c9313820603e5642c47a3f84a05e9180b16a4c18e4a0e78a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_861935fa55e72f85c9313820603e5642c47a3f84a05e9180b16a4c18e4a0e78a->enter($__internal_861935fa55e72f85c9313820603e5642c47a3f84a05e9180b16a4c18e4a0e78a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "checkbox_widget"));

        // line 154
        $context["parent_label_class"] = ((array_key_exists("parent_label_class", $context)) ? (_twig_default_filter(($context["parent_label_class"] ?? $this->getContext($context, "parent_label_class")), (($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")))) : ((($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : (""))));
        // line 155
        if (twig_in_filter("checkbox-inline", ($context["parent_label_class"] ?? $this->getContext($context, "parent_label_class")))) {
            // line 156
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'label', array("widget" => $this->renderParentBlock("checkbox_widget", $context, $blocks)));
        } else {
            // line 158
            echo "<div class=\"checkbox\">";
            // line 159
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'label', array("widget" => $this->renderParentBlock("checkbox_widget", $context, $blocks)));
            // line 160
            echo "</div>";
        }
        
        $__internal_861935fa55e72f85c9313820603e5642c47a3f84a05e9180b16a4c18e4a0e78a->leave($__internal_861935fa55e72f85c9313820603e5642c47a3f84a05e9180b16a4c18e4a0e78a_prof);

        
        $__internal_19a4909551a253bcec38acc800eb1672e06503564af5a6fed0b84538be95fcf2->leave($__internal_19a4909551a253bcec38acc800eb1672e06503564af5a6fed0b84538be95fcf2_prof);

    }

    // line 164
    public function block_radio_widget($context, array $blocks = array())
    {
        $__internal_2d8aab51a23a64c1df63fa06f89cfa77a501f4a2bd37d72fd443705b6b827792 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2d8aab51a23a64c1df63fa06f89cfa77a501f4a2bd37d72fd443705b6b827792->enter($__internal_2d8aab51a23a64c1df63fa06f89cfa77a501f4a2bd37d72fd443705b6b827792_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "radio_widget"));

        $__internal_84e113380e6ee8ffd53560563e5732e777cc62ebc7c336bcb94ca51896481d10 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_84e113380e6ee8ffd53560563e5732e777cc62ebc7c336bcb94ca51896481d10->enter($__internal_84e113380e6ee8ffd53560563e5732e777cc62ebc7c336bcb94ca51896481d10_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "radio_widget"));

        // line 165
        $context["parent_label_class"] = ((array_key_exists("parent_label_class", $context)) ? (_twig_default_filter(($context["parent_label_class"] ?? $this->getContext($context, "parent_label_class")), (($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")))) : ((($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : (""))));
        // line 166
        if (twig_in_filter("radio-inline", ($context["parent_label_class"] ?? $this->getContext($context, "parent_label_class")))) {
            // line 167
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'label', array("widget" => $this->renderParentBlock("radio_widget", $context, $blocks)));
        } else {
            // line 169
            echo "<div class=\"radio\">";
            // line 170
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'label', array("widget" => $this->renderParentBlock("radio_widget", $context, $blocks)));
            // line 171
            echo "</div>";
        }
        
        $__internal_84e113380e6ee8ffd53560563e5732e777cc62ebc7c336bcb94ca51896481d10->leave($__internal_84e113380e6ee8ffd53560563e5732e777cc62ebc7c336bcb94ca51896481d10_prof);

        
        $__internal_2d8aab51a23a64c1df63fa06f89cfa77a501f4a2bd37d72fd443705b6b827792->leave($__internal_2d8aab51a23a64c1df63fa06f89cfa77a501f4a2bd37d72fd443705b6b827792_prof);

    }

    // line 177
    public function block_form_label($context, array $blocks = array())
    {
        $__internal_4156afe88de8b3d185ef24f6a0d083e3a669d802f510f7fc23605fc6d6959a8c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4156afe88de8b3d185ef24f6a0d083e3a669d802f510f7fc23605fc6d6959a8c->enter($__internal_4156afe88de8b3d185ef24f6a0d083e3a669d802f510f7fc23605fc6d6959a8c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_label"));

        $__internal_f245fb4496478c9a4eecdb12d0e5f9c276a2f4002817addb1fea5c89d7193f25 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f245fb4496478c9a4eecdb12d0e5f9c276a2f4002817addb1fea5c89d7193f25->enter($__internal_f245fb4496478c9a4eecdb12d0e5f9c276a2f4002817addb1fea5c89d7193f25_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_label"));

        // line 178
        $context["label_attr"] = twig_array_merge(($context["label_attr"] ?? $this->getContext($context, "label_attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")) . " control-label"))));
        // line 179
        $this->displayParentBlock("form_label", $context, $blocks);
        
        $__internal_f245fb4496478c9a4eecdb12d0e5f9c276a2f4002817addb1fea5c89d7193f25->leave($__internal_f245fb4496478c9a4eecdb12d0e5f9c276a2f4002817addb1fea5c89d7193f25_prof);

        
        $__internal_4156afe88de8b3d185ef24f6a0d083e3a669d802f510f7fc23605fc6d6959a8c->leave($__internal_4156afe88de8b3d185ef24f6a0d083e3a669d802f510f7fc23605fc6d6959a8c_prof);

    }

    // line 182
    public function block_choice_label($context, array $blocks = array())
    {
        $__internal_769332bae3394c5b5f60e1b49c7c0be4a4e746d6e540c844c79f58faea03815b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_769332bae3394c5b5f60e1b49c7c0be4a4e746d6e540c844c79f58faea03815b->enter($__internal_769332bae3394c5b5f60e1b49c7c0be4a4e746d6e540c844c79f58faea03815b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "choice_label"));

        $__internal_1e88d9e0401f010bb2c716e025aa32a458f19dfbb161246ecfcdde7455557e15 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1e88d9e0401f010bb2c716e025aa32a458f19dfbb161246ecfcdde7455557e15->enter($__internal_1e88d9e0401f010bb2c716e025aa32a458f19dfbb161246ecfcdde7455557e15_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "choice_label"));

        // line 184
        $context["label_attr"] = twig_array_merge(($context["label_attr"] ?? $this->getContext($context, "label_attr")), array("class" => twig_trim_filter(twig_replace_filter((($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")), array("checkbox-inline" => "", "radio-inline" => "")))));
        // line 185
        $this->displayBlock("form_label", $context, $blocks);
        
        $__internal_1e88d9e0401f010bb2c716e025aa32a458f19dfbb161246ecfcdde7455557e15->leave($__internal_1e88d9e0401f010bb2c716e025aa32a458f19dfbb161246ecfcdde7455557e15_prof);

        
        $__internal_769332bae3394c5b5f60e1b49c7c0be4a4e746d6e540c844c79f58faea03815b->leave($__internal_769332bae3394c5b5f60e1b49c7c0be4a4e746d6e540c844c79f58faea03815b_prof);

    }

    // line 188
    public function block_checkbox_label($context, array $blocks = array())
    {
        $__internal_0b85cadfaa32909c2ee83d2adcaaa88ee99d55f217a211af38b864109447cbcb = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0b85cadfaa32909c2ee83d2adcaaa88ee99d55f217a211af38b864109447cbcb->enter($__internal_0b85cadfaa32909c2ee83d2adcaaa88ee99d55f217a211af38b864109447cbcb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "checkbox_label"));

        $__internal_13b1fbb70aa9d279df60c35e39b28a430ff4a41523ddff7161cf4b91ec8c6cc9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_13b1fbb70aa9d279df60c35e39b28a430ff4a41523ddff7161cf4b91ec8c6cc9->enter($__internal_13b1fbb70aa9d279df60c35e39b28a430ff4a41523ddff7161cf4b91ec8c6cc9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "checkbox_label"));

        // line 189
        $context["label_attr"] = twig_array_merge(($context["label_attr"] ?? $this->getContext($context, "label_attr")), array("for" => ($context["id"] ?? $this->getContext($context, "id"))));
        // line 191
        $this->displayBlock("checkbox_radio_label", $context, $blocks);
        
        $__internal_13b1fbb70aa9d279df60c35e39b28a430ff4a41523ddff7161cf4b91ec8c6cc9->leave($__internal_13b1fbb70aa9d279df60c35e39b28a430ff4a41523ddff7161cf4b91ec8c6cc9_prof);

        
        $__internal_0b85cadfaa32909c2ee83d2adcaaa88ee99d55f217a211af38b864109447cbcb->leave($__internal_0b85cadfaa32909c2ee83d2adcaaa88ee99d55f217a211af38b864109447cbcb_prof);

    }

    // line 194
    public function block_radio_label($context, array $blocks = array())
    {
        $__internal_d07edaed692238aefd00a5df836dd5fcc3d40cba21b4fe8d2564b0131eb6bd7e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d07edaed692238aefd00a5df836dd5fcc3d40cba21b4fe8d2564b0131eb6bd7e->enter($__internal_d07edaed692238aefd00a5df836dd5fcc3d40cba21b4fe8d2564b0131eb6bd7e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "radio_label"));

        $__internal_88f2f429c0a5914c4f5e8584511a68fec8448d96b34b66a6b1f6659e3c0fe82d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_88f2f429c0a5914c4f5e8584511a68fec8448d96b34b66a6b1f6659e3c0fe82d->enter($__internal_88f2f429c0a5914c4f5e8584511a68fec8448d96b34b66a6b1f6659e3c0fe82d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "radio_label"));

        // line 195
        $context["label_attr"] = twig_array_merge(($context["label_attr"] ?? $this->getContext($context, "label_attr")), array("for" => ($context["id"] ?? $this->getContext($context, "id"))));
        // line 197
        $this->displayBlock("checkbox_radio_label", $context, $blocks);
        
        $__internal_88f2f429c0a5914c4f5e8584511a68fec8448d96b34b66a6b1f6659e3c0fe82d->leave($__internal_88f2f429c0a5914c4f5e8584511a68fec8448d96b34b66a6b1f6659e3c0fe82d_prof);

        
        $__internal_d07edaed692238aefd00a5df836dd5fcc3d40cba21b4fe8d2564b0131eb6bd7e->leave($__internal_d07edaed692238aefd00a5df836dd5fcc3d40cba21b4fe8d2564b0131eb6bd7e_prof);

    }

    // line 200
    public function block_checkbox_radio_label($context, array $blocks = array())
    {
        $__internal_81ec463e282a5847d55e528db1e9c8e6649c19705e607819b4c43a2905d7491c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_81ec463e282a5847d55e528db1e9c8e6649c19705e607819b4c43a2905d7491c->enter($__internal_81ec463e282a5847d55e528db1e9c8e6649c19705e607819b4c43a2905d7491c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "checkbox_radio_label"));

        $__internal_b6074137af3f9544ca668e481cdc1dd80c30898cdcf68b372f62429637a38a38 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b6074137af3f9544ca668e481cdc1dd80c30898cdcf68b372f62429637a38a38->enter($__internal_b6074137af3f9544ca668e481cdc1dd80c30898cdcf68b372f62429637a38a38_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "checkbox_radio_label"));

        // line 201
        echo "    ";
        // line 202
        echo "    ";
        if (array_key_exists("widget", $context)) {
            // line 203
            echo "        ";
            if (($context["required"] ?? $this->getContext($context, "required"))) {
                // line 204
                echo "            ";
                $context["label_attr"] = twig_array_merge(($context["label_attr"] ?? $this->getContext($context, "label_attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")) . " required"))));
                // line 205
                echo "        ";
            }
            // line 206
            echo "        ";
            if (array_key_exists("parent_label_class", $context)) {
                // line 207
                echo "            ";
                $context["label_attr"] = twig_array_merge(($context["label_attr"] ?? $this->getContext($context, "label_attr")), array("class" => twig_trim_filter((((($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")) . " ") . ($context["parent_label_class"] ?? $this->getContext($context, "parent_label_class"))))));
                // line 208
                echo "        ";
            }
            // line 209
            echo "        ";
            if (( !(($context["label"] ?? $this->getContext($context, "label")) === false) && twig_test_empty(($context["label"] ?? $this->getContext($context, "label"))))) {
                // line 210
                if ( !twig_test_empty(($context["label_format"] ?? $this->getContext($context, "label_format")))) {
                    // line 211
                    $context["label"] = twig_replace_filter(($context["label_format"] ?? $this->getContext($context, "label_format")), array("%name%" =>                     // line 212
($context["name"] ?? $this->getContext($context, "name")), "%id%" =>                     // line 213
($context["id"] ?? $this->getContext($context, "id"))));
                } else {
                    // line 216
                    $context["label"] = $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->humanize(($context["name"] ?? $this->getContext($context, "name")));
                }
            }
            // line 219
            echo "        <label";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["label_attr"] ?? $this->getContext($context, "label_attr")));
            foreach ($context['_seq'] as $context["attrname"] => $context["attrvalue"]) {
                echo " ";
                echo twig_escape_filter($this->env, $context["attrname"], "html", null, true);
                echo "=\"";
                echo twig_escape_filter($this->env, $context["attrvalue"], "html", null, true);
                echo "\"";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['attrname'], $context['attrvalue'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            echo ">";
            // line 220
            echo ($context["widget"] ?? $this->getContext($context, "widget"));
            echo " ";
            echo twig_escape_filter($this->env, (( !(($context["label"] ?? $this->getContext($context, "label")) === false)) ? ((((($context["translation_domain"] ?? $this->getContext($context, "translation_domain")) === false)) ? (($context["label"] ?? $this->getContext($context, "label"))) : ($this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans(($context["label"] ?? $this->getContext($context, "label")), array(), ($context["translation_domain"] ?? $this->getContext($context, "translation_domain")))))) : ("")), "html", null, true);
            // line 221
            echo "</label>
    ";
        }
        
        $__internal_b6074137af3f9544ca668e481cdc1dd80c30898cdcf68b372f62429637a38a38->leave($__internal_b6074137af3f9544ca668e481cdc1dd80c30898cdcf68b372f62429637a38a38_prof);

        
        $__internal_81ec463e282a5847d55e528db1e9c8e6649c19705e607819b4c43a2905d7491c->leave($__internal_81ec463e282a5847d55e528db1e9c8e6649c19705e607819b4c43a2905d7491c_prof);

    }

    // line 227
    public function block_form_row($context, array $blocks = array())
    {
        $__internal_eac870d545be6658241e1192ed694e51978efdb49c4ca19c8d4afc20cf74e521 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_eac870d545be6658241e1192ed694e51978efdb49c4ca19c8d4afc20cf74e521->enter($__internal_eac870d545be6658241e1192ed694e51978efdb49c4ca19c8d4afc20cf74e521_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_row"));

        $__internal_2deaf6a8c4033afad8bf87c8f71b97356172858d036156bacba23393d8481003 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2deaf6a8c4033afad8bf87c8f71b97356172858d036156bacba23393d8481003->enter($__internal_2deaf6a8c4033afad8bf87c8f71b97356172858d036156bacba23393d8481003_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_row"));

        // line 228
        echo "<div class=\"form-group";
        if ((( !($context["compound"] ?? $this->getContext($context, "compound")) || ((array_key_exists("force_error", $context)) ? (_twig_default_filter(($context["force_error"] ?? $this->getContext($context, "force_error")), false)) : (false))) &&  !($context["valid"] ?? $this->getContext($context, "valid")))) {
            echo " has-error";
        }
        echo "\">";
        // line 229
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'label');
        // line 230
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget');
        // line 231
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'errors');
        // line 232
        echo "</div>";
        
        $__internal_2deaf6a8c4033afad8bf87c8f71b97356172858d036156bacba23393d8481003->leave($__internal_2deaf6a8c4033afad8bf87c8f71b97356172858d036156bacba23393d8481003_prof);

        
        $__internal_eac870d545be6658241e1192ed694e51978efdb49c4ca19c8d4afc20cf74e521->leave($__internal_eac870d545be6658241e1192ed694e51978efdb49c4ca19c8d4afc20cf74e521_prof);

    }

    // line 235
    public function block_button_row($context, array $blocks = array())
    {
        $__internal_8e24ff6a742ca2b5a25dd7fb0e87612d0ee1ff5a80daab0a8ce19c0ad7840784 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8e24ff6a742ca2b5a25dd7fb0e87612d0ee1ff5a80daab0a8ce19c0ad7840784->enter($__internal_8e24ff6a742ca2b5a25dd7fb0e87612d0ee1ff5a80daab0a8ce19c0ad7840784_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "button_row"));

        $__internal_c87635e437ecd00b4258ac7eec571650baa408f4832001d6e5383eebb71114eb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c87635e437ecd00b4258ac7eec571650baa408f4832001d6e5383eebb71114eb->enter($__internal_c87635e437ecd00b4258ac7eec571650baa408f4832001d6e5383eebb71114eb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "button_row"));

        // line 236
        echo "<div class=\"form-group\">";
        // line 237
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget');
        // line 238
        echo "</div>";
        
        $__internal_c87635e437ecd00b4258ac7eec571650baa408f4832001d6e5383eebb71114eb->leave($__internal_c87635e437ecd00b4258ac7eec571650baa408f4832001d6e5383eebb71114eb_prof);

        
        $__internal_8e24ff6a742ca2b5a25dd7fb0e87612d0ee1ff5a80daab0a8ce19c0ad7840784->leave($__internal_8e24ff6a742ca2b5a25dd7fb0e87612d0ee1ff5a80daab0a8ce19c0ad7840784_prof);

    }

    // line 241
    public function block_choice_row($context, array $blocks = array())
    {
        $__internal_5c2dfca7b546243e9f954e9dc0195c3d26ee75c0c0fa9780154c1b6af9d27dd3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5c2dfca7b546243e9f954e9dc0195c3d26ee75c0c0fa9780154c1b6af9d27dd3->enter($__internal_5c2dfca7b546243e9f954e9dc0195c3d26ee75c0c0fa9780154c1b6af9d27dd3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "choice_row"));

        $__internal_cc5ba64d8f374de5701bc63e3601f159171cea6591cb5dffdcc739fa0d285e9d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cc5ba64d8f374de5701bc63e3601f159171cea6591cb5dffdcc739fa0d285e9d->enter($__internal_cc5ba64d8f374de5701bc63e3601f159171cea6591cb5dffdcc739fa0d285e9d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "choice_row"));

        // line 242
        $context["force_error"] = true;
        // line 243
        $this->displayBlock("form_row", $context, $blocks);
        
        $__internal_cc5ba64d8f374de5701bc63e3601f159171cea6591cb5dffdcc739fa0d285e9d->leave($__internal_cc5ba64d8f374de5701bc63e3601f159171cea6591cb5dffdcc739fa0d285e9d_prof);

        
        $__internal_5c2dfca7b546243e9f954e9dc0195c3d26ee75c0c0fa9780154c1b6af9d27dd3->leave($__internal_5c2dfca7b546243e9f954e9dc0195c3d26ee75c0c0fa9780154c1b6af9d27dd3_prof);

    }

    // line 246
    public function block_date_row($context, array $blocks = array())
    {
        $__internal_fa6e7833df45fb7edae66b5946d3e84e55180941fe797a82365f10d07e7cecfe = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fa6e7833df45fb7edae66b5946d3e84e55180941fe797a82365f10d07e7cecfe->enter($__internal_fa6e7833df45fb7edae66b5946d3e84e55180941fe797a82365f10d07e7cecfe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "date_row"));

        $__internal_48e850585ccfdccb48251d1c779083c7571aca85a2bedde453bd3f16ee47be23 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_48e850585ccfdccb48251d1c779083c7571aca85a2bedde453bd3f16ee47be23->enter($__internal_48e850585ccfdccb48251d1c779083c7571aca85a2bedde453bd3f16ee47be23_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "date_row"));

        // line 247
        $context["force_error"] = true;
        // line 248
        $this->displayBlock("form_row", $context, $blocks);
        
        $__internal_48e850585ccfdccb48251d1c779083c7571aca85a2bedde453bd3f16ee47be23->leave($__internal_48e850585ccfdccb48251d1c779083c7571aca85a2bedde453bd3f16ee47be23_prof);

        
        $__internal_fa6e7833df45fb7edae66b5946d3e84e55180941fe797a82365f10d07e7cecfe->leave($__internal_fa6e7833df45fb7edae66b5946d3e84e55180941fe797a82365f10d07e7cecfe_prof);

    }

    // line 251
    public function block_time_row($context, array $blocks = array())
    {
        $__internal_ceec45855ccc4a35bcf3c2acbe81571fb9c27b0d5bcf578b8d7efceac8b74f63 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ceec45855ccc4a35bcf3c2acbe81571fb9c27b0d5bcf578b8d7efceac8b74f63->enter($__internal_ceec45855ccc4a35bcf3c2acbe81571fb9c27b0d5bcf578b8d7efceac8b74f63_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "time_row"));

        $__internal_60b281f81b00bfd53f674a4755581f8f4ce4817fd5fec537347ae52b14980316 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_60b281f81b00bfd53f674a4755581f8f4ce4817fd5fec537347ae52b14980316->enter($__internal_60b281f81b00bfd53f674a4755581f8f4ce4817fd5fec537347ae52b14980316_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "time_row"));

        // line 252
        $context["force_error"] = true;
        // line 253
        $this->displayBlock("form_row", $context, $blocks);
        
        $__internal_60b281f81b00bfd53f674a4755581f8f4ce4817fd5fec537347ae52b14980316->leave($__internal_60b281f81b00bfd53f674a4755581f8f4ce4817fd5fec537347ae52b14980316_prof);

        
        $__internal_ceec45855ccc4a35bcf3c2acbe81571fb9c27b0d5bcf578b8d7efceac8b74f63->leave($__internal_ceec45855ccc4a35bcf3c2acbe81571fb9c27b0d5bcf578b8d7efceac8b74f63_prof);

    }

    // line 256
    public function block_datetime_row($context, array $blocks = array())
    {
        $__internal_cff2ef3b709725fe0dc0865457763c57c0f116b4a6701028954ae19d44befc27 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cff2ef3b709725fe0dc0865457763c57c0f116b4a6701028954ae19d44befc27->enter($__internal_cff2ef3b709725fe0dc0865457763c57c0f116b4a6701028954ae19d44befc27_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datetime_row"));

        $__internal_e54167631486049e31aec39fced72c48dd6ded6e639fa229f8277db024fe2fda = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e54167631486049e31aec39fced72c48dd6ded6e639fa229f8277db024fe2fda->enter($__internal_e54167631486049e31aec39fced72c48dd6ded6e639fa229f8277db024fe2fda_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datetime_row"));

        // line 257
        $context["force_error"] = true;
        // line 258
        $this->displayBlock("form_row", $context, $blocks);
        
        $__internal_e54167631486049e31aec39fced72c48dd6ded6e639fa229f8277db024fe2fda->leave($__internal_e54167631486049e31aec39fced72c48dd6ded6e639fa229f8277db024fe2fda_prof);

        
        $__internal_cff2ef3b709725fe0dc0865457763c57c0f116b4a6701028954ae19d44befc27->leave($__internal_cff2ef3b709725fe0dc0865457763c57c0f116b4a6701028954ae19d44befc27_prof);

    }

    // line 261
    public function block_checkbox_row($context, array $blocks = array())
    {
        $__internal_b5610043a0a6fc2516a3681fee9096760a019358879c743e64f67ab74b0f62e9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b5610043a0a6fc2516a3681fee9096760a019358879c743e64f67ab74b0f62e9->enter($__internal_b5610043a0a6fc2516a3681fee9096760a019358879c743e64f67ab74b0f62e9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "checkbox_row"));

        $__internal_4a3151cfed9d82dfd663eebbfb238a74552df80e32165566c8166e86c953c376 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4a3151cfed9d82dfd663eebbfb238a74552df80e32165566c8166e86c953c376->enter($__internal_4a3151cfed9d82dfd663eebbfb238a74552df80e32165566c8166e86c953c376_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "checkbox_row"));

        // line 262
        echo "<div class=\"form-group";
        if ( !($context["valid"] ?? $this->getContext($context, "valid"))) {
            echo " has-error";
        }
        echo "\">";
        // line 263
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget');
        // line 264
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'errors');
        // line 265
        echo "</div>";
        
        $__internal_4a3151cfed9d82dfd663eebbfb238a74552df80e32165566c8166e86c953c376->leave($__internal_4a3151cfed9d82dfd663eebbfb238a74552df80e32165566c8166e86c953c376_prof);

        
        $__internal_b5610043a0a6fc2516a3681fee9096760a019358879c743e64f67ab74b0f62e9->leave($__internal_b5610043a0a6fc2516a3681fee9096760a019358879c743e64f67ab74b0f62e9_prof);

    }

    // line 268
    public function block_radio_row($context, array $blocks = array())
    {
        $__internal_a36e4ffe60bf2c7f01989409425b91979c121ef212bb1097d93970df56d9eb48 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a36e4ffe60bf2c7f01989409425b91979c121ef212bb1097d93970df56d9eb48->enter($__internal_a36e4ffe60bf2c7f01989409425b91979c121ef212bb1097d93970df56d9eb48_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "radio_row"));

        $__internal_facbfabaafa472b89a6d179df1de778a90be7645ceb8e2a0ee8456942271ac68 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_facbfabaafa472b89a6d179df1de778a90be7645ceb8e2a0ee8456942271ac68->enter($__internal_facbfabaafa472b89a6d179df1de778a90be7645ceb8e2a0ee8456942271ac68_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "radio_row"));

        // line 269
        echo "<div class=\"form-group";
        if ( !($context["valid"] ?? $this->getContext($context, "valid"))) {
            echo " has-error";
        }
        echo "\">";
        // line 270
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget');
        // line 271
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'errors');
        // line 272
        echo "</div>";
        
        $__internal_facbfabaafa472b89a6d179df1de778a90be7645ceb8e2a0ee8456942271ac68->leave($__internal_facbfabaafa472b89a6d179df1de778a90be7645ceb8e2a0ee8456942271ac68_prof);

        
        $__internal_a36e4ffe60bf2c7f01989409425b91979c121ef212bb1097d93970df56d9eb48->leave($__internal_a36e4ffe60bf2c7f01989409425b91979c121ef212bb1097d93970df56d9eb48_prof);

    }

    // line 277
    public function block_form_errors($context, array $blocks = array())
    {
        $__internal_fd9986c8abbdd9bdbeddd443e7886be3904e9e203a9f72045b8c1afeec386edf = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fd9986c8abbdd9bdbeddd443e7886be3904e9e203a9f72045b8c1afeec386edf->enter($__internal_fd9986c8abbdd9bdbeddd443e7886be3904e9e203a9f72045b8c1afeec386edf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_errors"));

        $__internal_50eda3a78e8e00453a925acfe97321ceca2b3959086d0b796b2cd02893883436 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_50eda3a78e8e00453a925acfe97321ceca2b3959086d0b796b2cd02893883436->enter($__internal_50eda3a78e8e00453a925acfe97321ceca2b3959086d0b796b2cd02893883436_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_errors"));

        // line 278
        if ((twig_length_filter($this->env, ($context["errors"] ?? $this->getContext($context, "errors"))) > 0)) {
            // line 279
            if ($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "parent", array())) {
                echo "<span class=\"help-block\">";
            } else {
                echo "<div class=\"alert alert-danger\">";
            }
            // line 280
            echo "    <ul class=\"list-unstyled\">";
            // line 281
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["errors"] ?? $this->getContext($context, "errors")));
            foreach ($context['_seq'] as $context["_key"] => $context["error"]) {
                // line 282
                echo "<li><span class=\"glyphicon glyphicon-exclamation-sign\"></span> ";
                echo twig_escape_filter($this->env, $this->getAttribute($context["error"], "message", array()), "html", null, true);
                echo "</li>";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['error'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 284
            echo "</ul>
    ";
            // line 285
            if ($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "parent", array())) {
                echo "</span>";
            } else {
                echo "</div>";
            }
        }
        
        $__internal_50eda3a78e8e00453a925acfe97321ceca2b3959086d0b796b2cd02893883436->leave($__internal_50eda3a78e8e00453a925acfe97321ceca2b3959086d0b796b2cd02893883436_prof);

        
        $__internal_fd9986c8abbdd9bdbeddd443e7886be3904e9e203a9f72045b8c1afeec386edf->leave($__internal_fd9986c8abbdd9bdbeddd443e7886be3904e9e203a9f72045b8c1afeec386edf_prof);

    }

    public function getTemplateName()
    {
        return "bootstrap_3_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  1139 => 285,  1136 => 284,  1128 => 282,  1124 => 281,  1122 => 280,  1116 => 279,  1114 => 278,  1105 => 277,  1095 => 272,  1093 => 271,  1091 => 270,  1085 => 269,  1076 => 268,  1066 => 265,  1064 => 264,  1062 => 263,  1056 => 262,  1047 => 261,  1037 => 258,  1035 => 257,  1026 => 256,  1016 => 253,  1014 => 252,  1005 => 251,  995 => 248,  993 => 247,  984 => 246,  974 => 243,  972 => 242,  963 => 241,  953 => 238,  951 => 237,  949 => 236,  940 => 235,  930 => 232,  928 => 231,  926 => 230,  924 => 229,  918 => 228,  909 => 227,  897 => 221,  893 => 220,  878 => 219,  874 => 216,  871 => 213,  870 => 212,  869 => 211,  867 => 210,  864 => 209,  861 => 208,  858 => 207,  855 => 206,  852 => 205,  849 => 204,  846 => 203,  843 => 202,  841 => 201,  832 => 200,  822 => 197,  820 => 195,  811 => 194,  801 => 191,  799 => 189,  790 => 188,  780 => 185,  778 => 184,  769 => 182,  759 => 179,  757 => 178,  748 => 177,  737 => 171,  735 => 170,  733 => 169,  730 => 167,  728 => 166,  726 => 165,  717 => 164,  706 => 160,  704 => 159,  702 => 158,  699 => 156,  697 => 155,  695 => 154,  686 => 153,  675 => 149,  669 => 146,  668 => 145,  667 => 144,  663 => 143,  659 => 142,  652 => 138,  651 => 137,  650 => 136,  646 => 135,  644 => 134,  635 => 133,  625 => 130,  623 => 129,  614 => 128,  603 => 124,  599 => 123,  594 => 119,  588 => 118,  582 => 117,  576 => 116,  570 => 115,  564 => 114,  558 => 113,  552 => 112,  547 => 108,  541 => 107,  535 => 106,  529 => 105,  523 => 104,  517 => 103,  511 => 102,  505 => 101,  500 => 98,  497 => 97,  495 => 96,  491 => 95,  489 => 94,  486 => 92,  484 => 91,  475 => 90,  463 => 85,  460 => 84,  450 => 83,  445 => 81,  443 => 80,  441 => 79,  438 => 77,  436 => 76,  427 => 75,  415 => 70,  413 => 69,  411 => 67,  410 => 66,  409 => 65,  408 => 64,  403 => 62,  401 => 61,  399 => 60,  396 => 58,  394 => 57,  385 => 56,  374 => 52,  372 => 51,  370 => 50,  368 => 49,  366 => 48,  362 => 47,  360 => 46,  357 => 44,  355 => 43,  346 => 42,  335 => 38,  333 => 37,  331 => 36,  322 => 35,  312 => 32,  306 => 30,  304 => 29,  302 => 28,  296 => 26,  293 => 25,  291 => 24,  288 => 23,  279 => 22,  269 => 19,  267 => 18,  258 => 17,  248 => 14,  246 => 13,  237 => 12,  227 => 9,  224 => 7,  222 => 6,  213 => 5,  203 => 277,  200 => 276,  197 => 274,  195 => 268,  192 => 267,  190 => 261,  187 => 260,  185 => 256,  182 => 255,  180 => 251,  177 => 250,  175 => 246,  172 => 245,  170 => 241,  167 => 240,  165 => 235,  162 => 234,  160 => 227,  157 => 226,  154 => 224,  152 => 200,  149 => 199,  147 => 194,  144 => 193,  142 => 188,  139 => 187,  137 => 182,  134 => 181,  132 => 177,  129 => 176,  126 => 174,  124 => 164,  121 => 163,  119 => 153,  116 => 152,  114 => 133,  111 => 132,  109 => 128,  107 => 90,  105 => 75,  102 => 74,  100 => 56,  97 => 55,  95 => 42,  92 => 41,  90 => 35,  87 => 34,  85 => 22,  82 => 21,  80 => 17,  77 => 16,  75 => 12,  72 => 11,  70 => 5,  67 => 4,  64 => 2,  14 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% use \"form_div_layout.html.twig\" %}

{# Widgets #}

{% block form_widget_simple -%}
    {% if type is not defined or type not in ['file', 'hidden'] %}
        {%- set attr = attr|merge({class: (attr.class|default('') ~ ' form-control')|trim}) -%}
    {% endif %}
    {{- parent() -}}
{%- endblock form_widget_simple %}

{% block textarea_widget -%}
    {% set attr = attr|merge({class: (attr.class|default('') ~ ' form-control')|trim}) %}
    {{- parent() -}}
{%- endblock textarea_widget %}

{% block button_widget -%}
    {% set attr = attr|merge({class: (attr.class|default('btn-default') ~ ' btn')|trim}) %}
    {{- parent() -}}
{%- endblock %}

{% block money_widget -%}
    <div class=\"input-group\">
        {% set append = money_pattern starts with '{{' %}
        {% if not append %}
            <span class=\"input-group-addon\">{{ money_pattern|replace({ '{{ widget }}':''}) }}</span>
        {% endif %}
        {{- block('form_widget_simple') -}}
        {% if append %}
            <span class=\"input-group-addon\">{{ money_pattern|replace({ '{{ widget }}':''}) }}</span>
        {% endif %}
    </div>
{%- endblock money_widget %}

{% block percent_widget -%}
    <div class=\"input-group\">
        {{- block('form_widget_simple') -}}
        <span class=\"input-group-addon\">%</span>
    </div>
{%- endblock percent_widget %}

{% block datetime_widget -%}
    {% if widget == 'single_text' %}
        {{- block('form_widget_simple') -}}
    {% else -%}
        {% set attr = attr|merge({class: (attr.class|default('') ~ ' form-inline')|trim}) -%}
        <div {{ block('widget_container_attributes') }}>
            {{- form_errors(form.date) -}}
            {{- form_errors(form.time) -}}
            {{- form_widget(form.date, { datetime: true } ) -}}
            {{- form_widget(form.time, { datetime: true } ) -}}
        </div>
    {%- endif %}
{%- endblock datetime_widget %}

{% block date_widget -%}
    {% if widget == 'single_text' %}
        {{- block('form_widget_simple') -}}
    {% else -%}
        {% set attr = attr|merge({class: (attr.class|default('') ~ ' form-inline')|trim}) -%}
        {% if datetime is not defined or not datetime -%}
            <div {{ block('widget_container_attributes') -}}>
        {%- endif %}
            {{- date_pattern|replace({
                '{{ year }}': form_widget(form.year),
                '{{ month }}': form_widget(form.month),
                '{{ day }}': form_widget(form.day),
            })|raw -}}
        {% if datetime is not defined or not datetime -%}
            </div>
        {%- endif -%}
    {% endif %}
{%- endblock date_widget %}

{% block time_widget -%}
    {% if widget == 'single_text' %}
        {{- block('form_widget_simple') -}}
    {% else -%}
        {% set attr = attr|merge({class: (attr.class|default('') ~ ' form-inline')|trim}) -%}
        {% if datetime is not defined or false == datetime -%}
            <div {{ block('widget_container_attributes') -}}>
        {%- endif -%}
        {{- form_widget(form.hour) }}{% if with_minutes %}:{{ form_widget(form.minute) }}{% endif %}{% if with_seconds %}:{{ form_widget(form.second) }}{% endif %}
        {% if datetime is not defined or false == datetime -%}
            </div>
        {%- endif -%}
    {% endif %}
{%- endblock time_widget %}

{%- block dateinterval_widget -%}
    {%- if widget == 'single_text' -%}
        {{- block('form_widget_simple') -}}
    {%- else -%}
        {%- set attr = attr|merge({class: (attr.class|default('') ~ ' form-inline')|trim}) -%}
        <div {{ block('widget_container_attributes') }}>
            {{- form_errors(form) -}}
            <div class=\"table-responsive\">
                <table class=\"table {{ table_class|default('table-bordered table-condensed table-striped') }}\">
                    <thead>
                    <tr>
                        {%- if with_years %}<th>{{ form_label(form.years) }}</th>{% endif -%}
                        {%- if with_months %}<th>{{ form_label(form.months) }}</th>{% endif -%}
                        {%- if with_weeks %}<th>{{ form_label(form.weeks) }}</th>{% endif -%}
                        {%- if with_days %}<th>{{ form_label(form.days) }}</th>{% endif -%}
                        {%- if with_hours %}<th>{{ form_label(form.hours) }}</th>{% endif -%}
                        {%- if with_minutes %}<th>{{ form_label(form.minutes) }}</th>{% endif -%}
                        {%- if with_seconds %}<th>{{ form_label(form.seconds) }}</th>{% endif -%}
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        {%- if with_years %}<td>{{ form_widget(form.years) }}</td>{% endif -%}
                        {%- if with_months %}<td>{{ form_widget(form.months) }}</td>{% endif -%}
                        {%- if with_weeks %}<td>{{ form_widget(form.weeks) }}</td>{% endif -%}
                        {%- if with_days %}<td>{{ form_widget(form.days) }}</td>{% endif -%}
                        {%- if with_hours %}<td>{{ form_widget(form.hours) }}</td>{% endif -%}
                        {%- if with_minutes %}<td>{{ form_widget(form.minutes) }}</td>{% endif -%}
                        {%- if with_seconds %}<td>{{ form_widget(form.seconds) }}</td>{% endif -%}
                    </tr>
                    </tbody>
                </table>
            </div>
            {%- if with_invert %}{{ form_widget(form.invert) }}{% endif -%}
        </div>
    {%- endif -%}
{%- endblock dateinterval_widget -%}

{% block choice_widget_collapsed -%}
    {% set attr = attr|merge({class: (attr.class|default('') ~ ' form-control')|trim}) %}
    {{- parent() -}}
{%- endblock %}

{% block choice_widget_expanded -%}
    {% if '-inline' in label_attr.class|default('') -%}
        {%- for child in form %}
            {{- form_widget(child, {
                parent_label_class: label_attr.class|default(''),
                translation_domain: choice_translation_domain,
            }) -}}
        {% endfor -%}
    {%- else -%}
        <div {{ block('widget_container_attributes') }}>
            {%- for child in form %}
                {{- form_widget(child, {
                    parent_label_class: label_attr.class|default(''),
                    translation_domain: choice_translation_domain,
                }) -}}
            {% endfor -%}
        </div>
    {%- endif %}
{%- endblock choice_widget_expanded %}

{% block checkbox_widget -%}
    {%- set parent_label_class = parent_label_class|default(label_attr.class|default('')) -%}
    {% if 'checkbox-inline' in parent_label_class %}
        {{- form_label(form, null, { widget: parent() }) -}}
    {% else -%}
        <div class=\"checkbox\">
            {{- form_label(form, null, { widget: parent() }) -}}
        </div>
    {%- endif %}
{%- endblock checkbox_widget %}

{% block radio_widget -%}
    {%- set parent_label_class = parent_label_class|default(label_attr.class|default('')) -%}
    {% if 'radio-inline' in parent_label_class %}
        {{- form_label(form, null, { widget: parent() }) -}}
    {% else -%}
        <div class=\"radio\">
            {{- form_label(form, null, { widget: parent() }) -}}
        </div>
    {%- endif %}
{%- endblock radio_widget %}

{# Labels #}

{% block form_label -%}
    {%- set label_attr = label_attr|merge({class: (label_attr.class|default('') ~ ' control-label')|trim}) -%}
    {{- parent() -}}
{%- endblock form_label %}

{% block choice_label -%}
    {# remove the checkbox-inline and radio-inline class, it's only useful for embed labels #}
    {%- set label_attr = label_attr|merge({class: label_attr.class|default('')|replace({'checkbox-inline': '', 'radio-inline': ''})|trim}) -%}
    {{- block('form_label') -}}
{% endblock %}

{% block checkbox_label -%}
    {%- set label_attr = label_attr|merge({'for': id}) -%}

    {{- block('checkbox_radio_label') -}}
{%- endblock checkbox_label %}

{% block radio_label -%}
    {%- set label_attr = label_attr|merge({'for': id}) -%}

    {{- block('checkbox_radio_label') -}}
{%- endblock radio_label %}

{% block checkbox_radio_label %}
    {# Do not display the label if widget is not defined in order to prevent double label rendering #}
    {% if widget is defined %}
        {% if required %}
            {% set label_attr = label_attr|merge({class: (label_attr.class|default('') ~ ' required')|trim}) %}
        {% endif %}
        {% if parent_label_class is defined %}
            {% set label_attr = label_attr|merge({class: (label_attr.class|default('') ~ ' ' ~ parent_label_class)|trim}) %}
        {% endif %}
        {% if label is not same as(false) and label is empty %}
            {%- if label_format is not empty -%}
                {% set label = label_format|replace({
                    '%name%': name,
                    '%id%': id,
                }) %}
            {%- else -%}
                {% set label = name|humanize %}
            {%- endif -%}
        {% endif %}
        <label{% for attrname, attrvalue in label_attr %} {{ attrname }}=\"{{ attrvalue }}\"{% endfor %}>
            {{- widget|raw }} {{ label is not same as(false) ? (translation_domain is same as(false) ? label : label|trans({}, translation_domain)) -}}
        </label>
    {% endif %}
{% endblock checkbox_radio_label %}

{# Rows #}

{% block form_row -%}
    <div class=\"form-group{% if (not compound or force_error|default(false)) and not valid %} has-error{% endif %}\">
        {{- form_label(form) -}}
        {{- form_widget(form) -}}
        {{- form_errors(form) -}}
    </div>
{%- endblock form_row %}

{% block button_row -%}
    <div class=\"form-group\">
        {{- form_widget(form) -}}
    </div>
{%- endblock button_row %}

{% block choice_row -%}
    {% set force_error = true %}
    {{- block('form_row') }}
{%- endblock choice_row %}

{% block date_row -%}
    {% set force_error = true %}
    {{- block('form_row') }}
{%- endblock date_row %}

{% block time_row -%}
    {% set force_error = true %}
    {{- block('form_row') }}
{%- endblock time_row %}

{% block datetime_row -%}
    {% set force_error = true %}
    {{- block('form_row') }}
{%- endblock datetime_row %}

{% block checkbox_row -%}
    <div class=\"form-group{% if not valid %} has-error{% endif %}\">
        {{- form_widget(form) -}}
        {{- form_errors(form) -}}
    </div>
{%- endblock checkbox_row %}

{% block radio_row -%}
    <div class=\"form-group{% if not valid %} has-error{% endif %}\">
        {{- form_widget(form) -}}
        {{- form_errors(form) -}}
    </div>
{%- endblock radio_row %}

{# Errors #}

{% block form_errors -%}
    {% if errors|length > 0 -%}
    {% if form.parent %}<span class=\"help-block\">{% else %}<div class=\"alert alert-danger\">{% endif %}
    <ul class=\"list-unstyled\">
        {%- for error in errors -%}
            <li><span class=\"glyphicon glyphicon-exclamation-sign\"></span> {{ error.message }}</li>
        {%- endfor -%}
    </ul>
    {% if form.parent %}</span>{% else %}</div>{% endif %}
    {%- endif %}
{%- endblock form_errors %}
", "bootstrap_3_layout.html.twig", "C:\\xampp\\htdocs\\PHPWeb\\Blog\\vendor\\symfony\\symfony\\src\\Symfony\\Bridge\\Twig\\Resources\\views\\Form\\bootstrap_3_layout.html.twig");
    }
}
