<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_98490afa0653a706fe19f3dd5c6c7a0a5522f04057346f0f1ba37cbc48fd3e3b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3f545f98c2badd30006f23a63f0604e2363b18c29f9e0b0e2b9feaadb2bc8255 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3f545f98c2badd30006f23a63f0604e2363b18c29f9e0b0e2b9feaadb2bc8255->enter($__internal_3f545f98c2badd30006f23a63f0604e2363b18c29f9e0b0e2b9feaadb2bc8255_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $__internal_59ca24c27f285b2dd9327679ffa5c64d4e79667c8d50b80bd81941bc42083032 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_59ca24c27f285b2dd9327679ffa5c64d4e79667c8d50b80bd81941bc42083032->enter($__internal_59ca24c27f285b2dd9327679ffa5c64d4e79667c8d50b80bd81941bc42083032_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_3f545f98c2badd30006f23a63f0604e2363b18c29f9e0b0e2b9feaadb2bc8255->leave($__internal_3f545f98c2badd30006f23a63f0604e2363b18c29f9e0b0e2b9feaadb2bc8255_prof);

        
        $__internal_59ca24c27f285b2dd9327679ffa5c64d4e79667c8d50b80bd81941bc42083032->leave($__internal_59ca24c27f285b2dd9327679ffa5c64d4e79667c8d50b80bd81941bc42083032_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_7adaca66ac4a9a4d033ca0d13bb55e241845c12de2e28ad5dcc8d5eaa2d3979a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7adaca66ac4a9a4d033ca0d13bb55e241845c12de2e28ad5dcc8d5eaa2d3979a->enter($__internal_7adaca66ac4a9a4d033ca0d13bb55e241845c12de2e28ad5dcc8d5eaa2d3979a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_ae7a27e1797d97f58f03d9db47193917e4fd33586cc23c7755a3546408d13c61 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ae7a27e1797d97f58f03d9db47193917e4fd33586cc23c7755a3546408d13c61->enter($__internal_ae7a27e1797d97f58f03d9db47193917e4fd33586cc23c7755a3546408d13c61_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_ae7a27e1797d97f58f03d9db47193917e4fd33586cc23c7755a3546408d13c61->leave($__internal_ae7a27e1797d97f58f03d9db47193917e4fd33586cc23c7755a3546408d13c61_prof);

        
        $__internal_7adaca66ac4a9a4d033ca0d13bb55e241845c12de2e28ad5dcc8d5eaa2d3979a->leave($__internal_7adaca66ac4a9a4d033ca0d13bb55e241845c12de2e28ad5dcc8d5eaa2d3979a_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_f418b39aa2168f69e4099ae5fb9742eb2d308a70168b0faf4aab7d4bf9400750 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f418b39aa2168f69e4099ae5fb9742eb2d308a70168b0faf4aab7d4bf9400750->enter($__internal_f418b39aa2168f69e4099ae5fb9742eb2d308a70168b0faf4aab7d4bf9400750_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_cfeab8bf45246676ba41b741d95437f834f959609c6d4c38e84ba421c5b520a2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cfeab8bf45246676ba41b741d95437f834f959609c6d4c38e84ba421c5b520a2->enter($__internal_cfeab8bf45246676ba41b741d95437f834f959609c6d4c38e84ba421c5b520a2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_cfeab8bf45246676ba41b741d95437f834f959609c6d4c38e84ba421c5b520a2->leave($__internal_cfeab8bf45246676ba41b741d95437f834f959609c6d4c38e84ba421c5b520a2_prof);

        
        $__internal_f418b39aa2168f69e4099ae5fb9742eb2d308a70168b0faf4aab7d4bf9400750->leave($__internal_f418b39aa2168f69e4099ae5fb9742eb2d308a70168b0faf4aab7d4bf9400750_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_85183853e133e76e98fffc3bb7c0a5b0ed6098ae3bb9e8c82b28739cd15aa17e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_85183853e133e76e98fffc3bb7c0a5b0ed6098ae3bb9e8c82b28739cd15aa17e->enter($__internal_85183853e133e76e98fffc3bb7c0a5b0ed6098ae3bb9e8c82b28739cd15aa17e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_1ddd370eaeeebb72f1fc9d6bf4b51d8291b41f4740507cc4144eae6121c5d0d8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1ddd370eaeeebb72f1fc9d6bf4b51d8291b41f4740507cc4144eae6121c5d0d8->enter($__internal_1ddd370eaeeebb72f1fc9d6bf4b51d8291b41f4740507cc4144eae6121c5d0d8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_1ddd370eaeeebb72f1fc9d6bf4b51d8291b41f4740507cc4144eae6121c5d0d8->leave($__internal_1ddd370eaeeebb72f1fc9d6bf4b51d8291b41f4740507cc4144eae6121c5d0d8_prof);

        
        $__internal_85183853e133e76e98fffc3bb7c0a5b0ed6098ae3bb9e8c82b28739cd15aa17e->leave($__internal_85183853e133e76e98fffc3bb7c0a5b0ed6098ae3bb9e8c82b28739cd15aa17e_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "C:\\xampp\\htdocs\\PHPWeb\\Blog\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\router.html.twig");
    }
}
