<?php

/* article/create.html.twig */
class __TwigTemplate_edcc0217a35588dc48b4ad73bdf45ee0b14bfe120db1c6a0c807bb8d9c1b5b3c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "article/create.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_68fc4ca34732d3d4651cb581d323f42106d3f40c68b4b14dc8b8a86dc9434df9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_68fc4ca34732d3d4651cb581d323f42106d3f40c68b4b14dc8b8a86dc9434df9->enter($__internal_68fc4ca34732d3d4651cb581d323f42106d3f40c68b4b14dc8b8a86dc9434df9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "article/create.html.twig"));

        $__internal_ba091ee8614e159ccb61d6a49ae2b7a775e6ca9517e1e226ef0dcec049da3ac7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ba091ee8614e159ccb61d6a49ae2b7a775e6ca9517e1e226ef0dcec049da3ac7->enter($__internal_ba091ee8614e159ccb61d6a49ae2b7a775e6ca9517e1e226ef0dcec049da3ac7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "article/create.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_68fc4ca34732d3d4651cb581d323f42106d3f40c68b4b14dc8b8a86dc9434df9->leave($__internal_68fc4ca34732d3d4651cb581d323f42106d3f40c68b4b14dc8b8a86dc9434df9_prof);

        
        $__internal_ba091ee8614e159ccb61d6a49ae2b7a775e6ca9517e1e226ef0dcec049da3ac7->leave($__internal_ba091ee8614e159ccb61d6a49ae2b7a775e6ca9517e1e226ef0dcec049da3ac7_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_016ee6d547287df333af2e4d4e966c13e8dcdc3104df8f01ca22ee4aacce87e5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_016ee6d547287df333af2e4d4e966c13e8dcdc3104df8f01ca22ee4aacce87e5->enter($__internal_016ee6d547287df333af2e4d4e966c13e8dcdc3104df8f01ca22ee4aacce87e5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_914d8c44ffe09c30e5d9379b14ae94771bbb64553d1772f47cf2501095afc356 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_914d8c44ffe09c30e5d9379b14ae94771bbb64553d1772f47cf2501095afc356->enter($__internal_914d8c44ffe09c30e5d9379b14ae94771bbb64553d1772f47cf2501095afc356_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "    <div class=\"container body-content span=8 offset=2\">
        <div class=\"well\">
            <form class=\"form-horizontal\" action=\"";
        // line 6
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("article_create");
        echo "\" method=\"POST\">
                <fieldset>
                    <legend>New Post</legend>

                    <div class=\"form-group\">
                        <label class=\"col-sm-4 control-label\" for=\"article_title\">Post Title</label>
                        <div class=\"col-sm-4 \">
                            <input type=\"text\" class=\"form-control\" id=\"article_title\" placeholder=\"Post Title\"
                                   name=\"article[title]\">
                        </div>
                    </div>

                    <div class=\"form-group\">
                        <label class=\"col-sm-4 control-label\" for=\"article_content\">Content</label>
                        <div class=\"col-sm-6\">
                        <textarea class=\"form-control\" rows=\"6\" id=\"article_content\"
                                  name=\"article[content]\"></textarea>
                        </div>
                    </div>

                    ";
        // line 26
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "_token", array()), 'row');
        echo "

                    <div class=\"form-group\">
                        <div class=\"col-sm-4 col-sm-offset-4\">
                            <a class=\"btn btn-default\" href=\"";
        // line 30
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("blog_index");
        echo "\">Cancel</a>
                            <button type=\"submit\" class=\"btn btn-primary\">Submit</button>
                        </div>
                    </div>
                </fieldset>
            </form>
        </div>
    </div>
";
        
        $__internal_914d8c44ffe09c30e5d9379b14ae94771bbb64553d1772f47cf2501095afc356->leave($__internal_914d8c44ffe09c30e5d9379b14ae94771bbb64553d1772f47cf2501095afc356_prof);

        
        $__internal_016ee6d547287df333af2e4d4e966c13e8dcdc3104df8f01ca22ee4aacce87e5->leave($__internal_016ee6d547287df333af2e4d4e966c13e8dcdc3104df8f01ca22ee4aacce87e5_prof);

    }

    public function getTemplateName()
    {
        return "article/create.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  83 => 30,  76 => 26,  53 => 6,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block main %}
    <div class=\"container body-content span=8 offset=2\">
        <div class=\"well\">
            <form class=\"form-horizontal\" action=\"{{ path('article_create') }}\" method=\"POST\">
                <fieldset>
                    <legend>New Post</legend>

                    <div class=\"form-group\">
                        <label class=\"col-sm-4 control-label\" for=\"article_title\">Post Title</label>
                        <div class=\"col-sm-4 \">
                            <input type=\"text\" class=\"form-control\" id=\"article_title\" placeholder=\"Post Title\"
                                   name=\"article[title]\">
                        </div>
                    </div>

                    <div class=\"form-group\">
                        <label class=\"col-sm-4 control-label\" for=\"article_content\">Content</label>
                        <div class=\"col-sm-6\">
                        <textarea class=\"form-control\" rows=\"6\" id=\"article_content\"
                                  name=\"article[content]\"></textarea>
                        </div>
                    </div>

                    {{ form_row(form._token) }}

                    <div class=\"form-group\">
                        <div class=\"col-sm-4 col-sm-offset-4\">
                            <a class=\"btn btn-default\" href=\"{{ path('blog_index') }}\">Cancel</a>
                            <button type=\"submit\" class=\"btn btn-primary\">Submit</button>
                        </div>
                    </div>
                </fieldset>
            </form>
        </div>
    </div>
{% endblock %}", "article/create.html.twig", "C:\\xampp\\htdocs\\PHPWeb\\Blog\\app\\Resources\\views\\article\\create.html.twig");
    }
}
