<?php

/* article/article.html.twig */
class __TwigTemplate_177dd6dbaa52cfb30582516ab1b70553a96cf574679865c92f362df777cd4572 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "article/article.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f92605283bdfe7b2ccf80e407d860f858352d7fca7f6872ef966253b2fe440fd = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f92605283bdfe7b2ccf80e407d860f858352d7fca7f6872ef966253b2fe440fd->enter($__internal_f92605283bdfe7b2ccf80e407d860f858352d7fca7f6872ef966253b2fe440fd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "article/article.html.twig"));

        $__internal_8de25dbbb2eaa49516940a38402ec88866c6b793fde797773541df006b7de933 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8de25dbbb2eaa49516940a38402ec88866c6b793fde797773541df006b7de933->enter($__internal_8de25dbbb2eaa49516940a38402ec88866c6b793fde797773541df006b7de933_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "article/article.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f92605283bdfe7b2ccf80e407d860f858352d7fca7f6872ef966253b2fe440fd->leave($__internal_f92605283bdfe7b2ccf80e407d860f858352d7fca7f6872ef966253b2fe440fd_prof);

        
        $__internal_8de25dbbb2eaa49516940a38402ec88866c6b793fde797773541df006b7de933->leave($__internal_8de25dbbb2eaa49516940a38402ec88866c6b793fde797773541df006b7de933_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_4cc457bca44a2abb2b8c09067db266996daa9aa8acacd3b5ad2ec247d776383e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4cc457bca44a2abb2b8c09067db266996daa9aa8acacd3b5ad2ec247d776383e->enter($__internal_4cc457bca44a2abb2b8c09067db266996daa9aa8acacd3b5ad2ec247d776383e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_832d280e2de470dd9d51807ee62027ea3680f3b9a3045fe139e0bad4a3dec85a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_832d280e2de470dd9d51807ee62027ea3680f3b9a3045fe139e0bad4a3dec85a->enter($__internal_832d280e2de470dd9d51807ee62027ea3680f3b9a3045fe139e0bad4a3dec85a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "    <div class=\"container body-content\">
        <div class=\"row\">
            <div class=\"col-md-12\">
                <article>
                    <header>
                        <h2>";
        // line 9
        echo twig_escape_filter($this->env, $this->getAttribute(($context["article"] ?? $this->getContext($context, "article")), "title", array()), "html", null, true);
        echo "</h2>
                    </header>

                    <p>
                        ";
        // line 13
        echo twig_escape_filter($this->env, $this->getAttribute(($context["article"] ?? $this->getContext($context, "article")), "content", array()), "html", null, true);
        echo "
                    </p>

                    <small class=\"author\">
                        ";
        // line 17
        echo twig_escape_filter($this->env, $this->getAttribute(($context["article"] ?? $this->getContext($context, "article")), "author", array()), "html", null, true);
        echo "
                    </small>

                    <footer>
                        <div class=\"pull-right\">
                            ";
        // line 22
        if (($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "getUser", array(), "method") && ($this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "getUser", array(), "method"), "isAuthor", array(0 => ($context["article"] ?? $this->getContext($context, "article"))), "method") || $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "getUser", array(), "method"), "isAdmin", array(), "method")))) {
            // line 23
            echo "                            <a class=\"btn btn-default btn-xs\"
                               href=\"";
            // line 24
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("article_edit", array("id" => $this->getAttribute(($context["article"] ?? $this->getContext($context, "article")), "id", array()))), "html", null, true);
            echo "\">Edit &raquo;</a>
                            <a class=\"btn btn-default btn-xs\"
                               href=\"";
            // line 26
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("article_delete", array("id" => $this->getAttribute(($context["article"] ?? $this->getContext($context, "article")), "id", array()))), "html", null, true);
            echo "\">Delete &raquo;</a>
                                ";
        }
        // line 28
        echo "                            <a class=\"btn btn-default btn-xs\"
                               href=\"";
        // line 29
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("blog_index");
        echo "\">back &raquo;</a>
                        </div>
                    </footer>
                </article>
            </div>
        </div>
    </div>
";
        
        $__internal_832d280e2de470dd9d51807ee62027ea3680f3b9a3045fe139e0bad4a3dec85a->leave($__internal_832d280e2de470dd9d51807ee62027ea3680f3b9a3045fe139e0bad4a3dec85a_prof);

        
        $__internal_4cc457bca44a2abb2b8c09067db266996daa9aa8acacd3b5ad2ec247d776383e->leave($__internal_4cc457bca44a2abb2b8c09067db266996daa9aa8acacd3b5ad2ec247d776383e_prof);

    }

    public function getTemplateName()
    {
        return "article/article.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  96 => 29,  93 => 28,  88 => 26,  83 => 24,  80 => 23,  78 => 22,  70 => 17,  63 => 13,  56 => 9,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block main %}
    <div class=\"container body-content\">
        <div class=\"row\">
            <div class=\"col-md-12\">
                <article>
                    <header>
                        <h2>{{ article.title }}</h2>
                    </header>

                    <p>
                        {{ article.content }}
                    </p>

                    <small class=\"author\">
                        {{ article.author }}
                    </small>

                    <footer>
                        <div class=\"pull-right\">
                            {% if app.getUser() and (app.getUser().isAuthor(article) or app.getUser().isAdmin()) %}
                            <a class=\"btn btn-default btn-xs\"
                               href=\"{{ path('article_edit', {'id' : article.id}) }}\">Edit &raquo;</a>
                            <a class=\"btn btn-default btn-xs\"
                               href=\"{{ path('article_delete', {'id' : article.id}) }}\">Delete &raquo;</a>
                                {% endif %}
                            <a class=\"btn btn-default btn-xs\"
                               href=\"{{ path('blog_index') }}\">back &raquo;</a>
                        </div>
                    </footer>
                </article>
            </div>
        </div>
    </div>
{% endblock %}", "article/article.html.twig", "C:\\xampp\\htdocs\\PHPWeb\\Blog\\app\\Resources\\views\\article\\article.html.twig");
    }
}
