<?php

/* base.html.twig */
class __TwigTemplate_0fa398c33effe06a6d440259f1ea30db8d8d003a6df44f18a011851597090d4c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body_id' => array($this, 'block_body_id'),
            'header' => array($this, 'block_header'),
            'body' => array($this, 'block_body'),
            'main' => array($this, 'block_main'),
            'footer' => array($this, 'block_footer'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_bb975b6de1ed1153e586a1a859bfd82407343d2f37bae64124d78a275afe879a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_bb975b6de1ed1153e586a1a859bfd82407343d2f37bae64124d78a275afe879a->enter($__internal_bb975b6de1ed1153e586a1a859bfd82407343d2f37bae64124d78a275afe879a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_2054ad2e26eaf716421e3da841b61892a8d491bf3096baa1498e1eee290d68d0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2054ad2e26eaf716421e3da841b61892a8d491bf3096baa1498e1eee290d68d0->enter($__internal_2054ad2e26eaf716421e3da841b61892a8d491bf3096baa1498e1eee290d68d0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 6
        echo "<!DOCTYPE html>
<html lang=\"en-US\">
<head>
    <meta charset=\"UTF-8\"/>
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>
    <title>";
        // line 11
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
    ";
        // line 12
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 16
        echo "    <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\"/>
</head>

<body id=\"";
        // line 19
        $this->displayBlock('body_id', $context, $blocks);
        echo "\">

";
        // line 21
        $this->displayBlock('header', $context, $blocks);
        // line 70
        echo "
<div class=\"container body-container\">
    ";
        // line 72
        $this->displayBlock('body', $context, $blocks);
        // line 79
        echo "</div>

";
        // line 81
        $this->displayBlock('footer', $context, $blocks);
        // line 88
        echo "
";
        // line 89
        $this->displayBlock('javascripts', $context, $blocks);
        // line 95
        echo "
</body>
</html>
";
        
        $__internal_bb975b6de1ed1153e586a1a859bfd82407343d2f37bae64124d78a275afe879a->leave($__internal_bb975b6de1ed1153e586a1a859bfd82407343d2f37bae64124d78a275afe879a_prof);

        
        $__internal_2054ad2e26eaf716421e3da841b61892a8d491bf3096baa1498e1eee290d68d0->leave($__internal_2054ad2e26eaf716421e3da841b61892a8d491bf3096baa1498e1eee290d68d0_prof);

    }

    // line 11
    public function block_title($context, array $blocks = array())
    {
        $__internal_c3bf111e95c425553ce06e7a0be9b0f7096fa2853b037c4c56707abda00022dd = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c3bf111e95c425553ce06e7a0be9b0f7096fa2853b037c4c56707abda00022dd->enter($__internal_c3bf111e95c425553ce06e7a0be9b0f7096fa2853b037c4c56707abda00022dd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_0816a9c9a31dacd8993aa2744fc90801d70def7345652e888ba88d0aefa54b87 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0816a9c9a31dacd8993aa2744fc90801d70def7345652e888ba88d0aefa54b87->enter($__internal_0816a9c9a31dacd8993aa2744fc90801d70def7345652e888ba88d0aefa54b87_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "SoftUni Blog";
        
        $__internal_0816a9c9a31dacd8993aa2744fc90801d70def7345652e888ba88d0aefa54b87->leave($__internal_0816a9c9a31dacd8993aa2744fc90801d70def7345652e888ba88d0aefa54b87_prof);

        
        $__internal_c3bf111e95c425553ce06e7a0be9b0f7096fa2853b037c4c56707abda00022dd->leave($__internal_c3bf111e95c425553ce06e7a0be9b0f7096fa2853b037c4c56707abda00022dd_prof);

    }

    // line 12
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_b3eb70fb8f9deb2cd0aa8ca8d1c2b021a1f2d341788fa0a1f3f190acc72cf598 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b3eb70fb8f9deb2cd0aa8ca8d1c2b021a1f2d341788fa0a1f3f190acc72cf598->enter($__internal_b3eb70fb8f9deb2cd0aa8ca8d1c2b021a1f2d341788fa0a1f3f190acc72cf598_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_464ddcd0a772c0b4db06f15c57c110d5b7bfbf1ae6a4357b39adcc336637482d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_464ddcd0a772c0b4db06f15c57c110d5b7bfbf1ae6a4357b39adcc336637482d->enter($__internal_464ddcd0a772c0b4db06f15c57c110d5b7bfbf1ae6a4357b39adcc336637482d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 13
        echo "        <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/style.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" href=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/bootstrap-datetimepicker.min.css"), "html", null, true);
        echo "\">
    ";
        
        $__internal_464ddcd0a772c0b4db06f15c57c110d5b7bfbf1ae6a4357b39adcc336637482d->leave($__internal_464ddcd0a772c0b4db06f15c57c110d5b7bfbf1ae6a4357b39adcc336637482d_prof);

        
        $__internal_b3eb70fb8f9deb2cd0aa8ca8d1c2b021a1f2d341788fa0a1f3f190acc72cf598->leave($__internal_b3eb70fb8f9deb2cd0aa8ca8d1c2b021a1f2d341788fa0a1f3f190acc72cf598_prof);

    }

    // line 19
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_348e32098466450ef2449d0dd9da95e1de445cfd5927b64c7fbd04f111f0b8fd = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_348e32098466450ef2449d0dd9da95e1de445cfd5927b64c7fbd04f111f0b8fd->enter($__internal_348e32098466450ef2449d0dd9da95e1de445cfd5927b64c7fbd04f111f0b8fd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        $__internal_2ffcfffe92efe66ab0b6f89d492a556a6397434ccbb388387169377e436151a2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2ffcfffe92efe66ab0b6f89d492a556a6397434ccbb388387169377e436151a2->enter($__internal_2ffcfffe92efe66ab0b6f89d492a556a6397434ccbb388387169377e436151a2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        
        $__internal_2ffcfffe92efe66ab0b6f89d492a556a6397434ccbb388387169377e436151a2->leave($__internal_2ffcfffe92efe66ab0b6f89d492a556a6397434ccbb388387169377e436151a2_prof);

        
        $__internal_348e32098466450ef2449d0dd9da95e1de445cfd5927b64c7fbd04f111f0b8fd->leave($__internal_348e32098466450ef2449d0dd9da95e1de445cfd5927b64c7fbd04f111f0b8fd_prof);

    }

    // line 21
    public function block_header($context, array $blocks = array())
    {
        $__internal_f760c672e069f722b7dc933e80d390ec34386d33c42490e55ed8fc999223d94e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f760c672e069f722b7dc933e80d390ec34386d33c42490e55ed8fc999223d94e->enter($__internal_f760c672e069f722b7dc933e80d390ec34386d33c42490e55ed8fc999223d94e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header"));

        $__internal_1851fc1f48e9db7a2792e62403b80b877978c13dbf5f9e7bc8bd98a4c82e4a0e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1851fc1f48e9db7a2792e62403b80b877978c13dbf5f9e7bc8bd98a4c82e4a0e->enter($__internal_1851fc1f48e9db7a2792e62403b80b877978c13dbf5f9e7bc8bd98a4c82e4a0e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header"));

        // line 22
        echo "    <header>
        <div class=\"navbar navbar-default navbar-static-top\" role=\"navigation\">
            <div class=\"container\">
                <div class=\"navbar-header\">
                    <a href=\"";
        // line 26
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("blog_index");
        echo "\" class=\"navbar-brand\">SOFTUNI BLOG</a>

                    <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\".navbar-collapse\">
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                    </button>
                </div>
                <div class=\"navbar-collapse collapse\">
                    <ul class=\"nav navbar-nav navbar-right\">
                        ";
        // line 36
        if ($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array())) {
            // line 37
            echo "                            <li>
                                <a href=\"";
            // line 38
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("article_create");
            echo "\">
                                    Create Article
                                </a>
                            </li>
                            <li>
                                <a href=\"";
            // line 43
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("user_profile");
            echo "\">
                                    My Profile
                                </a>
                            </li>
                            <li>
                                <a href=\"";
            // line 48
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("security_logout");
            echo "\">
                                    Logout
                                </a>
                            </li>
                        ";
        } else {
            // line 53
            echo "                            <li>
                                <a href=\"";
            // line 54
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("user_register");
            echo "\">
                                    REGISTER
                                </a>
                            </li>
                            <li>
                                <a href=\"";
            // line 59
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("security_login");
            echo "\">
                                    LOGIN
                                </a>
                            </li>
                        ";
        }
        // line 64
        echo "                    </ul>
                </div>
            </div>
        </div>
    </header>
";
        
        $__internal_1851fc1f48e9db7a2792e62403b80b877978c13dbf5f9e7bc8bd98a4c82e4a0e->leave($__internal_1851fc1f48e9db7a2792e62403b80b877978c13dbf5f9e7bc8bd98a4c82e4a0e_prof);

        
        $__internal_f760c672e069f722b7dc933e80d390ec34386d33c42490e55ed8fc999223d94e->leave($__internal_f760c672e069f722b7dc933e80d390ec34386d33c42490e55ed8fc999223d94e_prof);

    }

    // line 72
    public function block_body($context, array $blocks = array())
    {
        $__internal_e03051c795c521ff05d0459295cdd063a1dfee71aec8c553d2bcdb6118dc5854 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e03051c795c521ff05d0459295cdd063a1dfee71aec8c553d2bcdb6118dc5854->enter($__internal_e03051c795c521ff05d0459295cdd063a1dfee71aec8c553d2bcdb6118dc5854_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_bceddcb6ceb40e237bec234bed657613aca5febbe808e7d7d7991b39a9f97150 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bceddcb6ceb40e237bec234bed657613aca5febbe808e7d7d7991b39a9f97150->enter($__internal_bceddcb6ceb40e237bec234bed657613aca5febbe808e7d7d7991b39a9f97150_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 73
        echo "        <div class=\"row\">
            <div id=\"main\" class=\"col-sm-9\">
                ";
        // line 75
        $this->displayBlock('main', $context, $blocks);
        // line 76
        echo "            </div>
        </div>
    ";
        
        $__internal_bceddcb6ceb40e237bec234bed657613aca5febbe808e7d7d7991b39a9f97150->leave($__internal_bceddcb6ceb40e237bec234bed657613aca5febbe808e7d7d7991b39a9f97150_prof);

        
        $__internal_e03051c795c521ff05d0459295cdd063a1dfee71aec8c553d2bcdb6118dc5854->leave($__internal_e03051c795c521ff05d0459295cdd063a1dfee71aec8c553d2bcdb6118dc5854_prof);

    }

    // line 75
    public function block_main($context, array $blocks = array())
    {
        $__internal_54228eaddd3c3e3196744a2069b243af5c5e7479204ed8f224041072f72fceb1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_54228eaddd3c3e3196744a2069b243af5c5e7479204ed8f224041072f72fceb1->enter($__internal_54228eaddd3c3e3196744a2069b243af5c5e7479204ed8f224041072f72fceb1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_0574f6ac48b1ad928626f52968e07c70b8ea20bbb34a08e8459e583f8526c9f9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0574f6ac48b1ad928626f52968e07c70b8ea20bbb34a08e8459e583f8526c9f9->enter($__internal_0574f6ac48b1ad928626f52968e07c70b8ea20bbb34a08e8459e583f8526c9f9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        
        $__internal_0574f6ac48b1ad928626f52968e07c70b8ea20bbb34a08e8459e583f8526c9f9->leave($__internal_0574f6ac48b1ad928626f52968e07c70b8ea20bbb34a08e8459e583f8526c9f9_prof);

        
        $__internal_54228eaddd3c3e3196744a2069b243af5c5e7479204ed8f224041072f72fceb1->leave($__internal_54228eaddd3c3e3196744a2069b243af5c5e7479204ed8f224041072f72fceb1_prof);

    }

    // line 81
    public function block_footer($context, array $blocks = array())
    {
        $__internal_5ff0c40b22461766328ef9ed1090cfa0c254e65a2b5d1646851f5332895519c0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5ff0c40b22461766328ef9ed1090cfa0c254e65a2b5d1646851f5332895519c0->enter($__internal_5ff0c40b22461766328ef9ed1090cfa0c254e65a2b5d1646851f5332895519c0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        $__internal_b1eafeaa756722249266bab7cc4ab4928ae666a504f6d43e950178b7f2b114ed = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b1eafeaa756722249266bab7cc4ab4928ae666a504f6d43e950178b7f2b114ed->enter($__internal_b1eafeaa756722249266bab7cc4ab4928ae666a504f6d43e950178b7f2b114ed_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        // line 82
        echo "    <footer>
        <div class=\"container modal-footer\">
            <p>&copy; 2016 - Software University Foundation</p>
        </div>
    </footer>
";
        
        $__internal_b1eafeaa756722249266bab7cc4ab4928ae666a504f6d43e950178b7f2b114ed->leave($__internal_b1eafeaa756722249266bab7cc4ab4928ae666a504f6d43e950178b7f2b114ed_prof);

        
        $__internal_5ff0c40b22461766328ef9ed1090cfa0c254e65a2b5d1646851f5332895519c0->leave($__internal_5ff0c40b22461766328ef9ed1090cfa0c254e65a2b5d1646851f5332895519c0_prof);

    }

    // line 89
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_5dc05516f8bdd0e1321ec9f1f89034333938238e516a3fbc144d5025f3bb10f5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5dc05516f8bdd0e1321ec9f1f89034333938238e516a3fbc144d5025f3bb10f5->enter($__internal_5dc05516f8bdd0e1321ec9f1f89034333938238e516a3fbc144d5025f3bb10f5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_cba220361b5f5a80d1a00166ea3652d554c0798f37aed9f5335239d445056178 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cba220361b5f5a80d1a00166ea3652d554c0798f37aed9f5335239d445056178->enter($__internal_cba220361b5f5a80d1a00166ea3652d554c0798f37aed9f5335239d445056178_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 90
        echo "    <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/jquery-2.2.4.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 91
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/moment.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 92
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/bootstrap.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 93
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/bootstrap-datetimepicker.min.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_cba220361b5f5a80d1a00166ea3652d554c0798f37aed9f5335239d445056178->leave($__internal_cba220361b5f5a80d1a00166ea3652d554c0798f37aed9f5335239d445056178_prof);

        
        $__internal_5dc05516f8bdd0e1321ec9f1f89034333938238e516a3fbc144d5025f3bb10f5->leave($__internal_5dc05516f8bdd0e1321ec9f1f89034333938238e516a3fbc144d5025f3bb10f5_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  332 => 93,  328 => 92,  324 => 91,  319 => 90,  310 => 89,  295 => 82,  286 => 81,  269 => 75,  257 => 76,  255 => 75,  251 => 73,  242 => 72,  227 => 64,  219 => 59,  211 => 54,  208 => 53,  200 => 48,  192 => 43,  184 => 38,  181 => 37,  179 => 36,  166 => 26,  160 => 22,  151 => 21,  134 => 19,  122 => 14,  117 => 13,  108 => 12,  90 => 11,  77 => 95,  75 => 89,  72 => 88,  70 => 81,  66 => 79,  64 => 72,  60 => 70,  58 => 21,  53 => 19,  46 => 16,  44 => 12,  40 => 11,  33 => 6,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#
   This is the base template used as the application layout which contains the
   common elements and decorates all the other templates.
   See http://symfony.com/doc/current/book/templating.html#template-inheritance-and-layouts
#}
<!DOCTYPE html>
<html lang=\"en-US\">
<head>
    <meta charset=\"UTF-8\"/>
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>
    <title>{% block title %}SoftUni Blog{% endblock %}</title>
    {% block stylesheets %}
        <link rel=\"stylesheet\" href=\"{{ asset('css/style.css') }}\">
        <link rel=\"stylesheet\" href=\"{{ asset('css/bootstrap-datetimepicker.min.css') }}\">
    {% endblock %}
    <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\"/>
</head>

<body id=\"{% block body_id %}{% endblock %}\">

{% block header %}
    <header>
        <div class=\"navbar navbar-default navbar-static-top\" role=\"navigation\">
            <div class=\"container\">
                <div class=\"navbar-header\">
                    <a href=\"{{ path('blog_index') }}\" class=\"navbar-brand\">SOFTUNI BLOG</a>

                    <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\".navbar-collapse\">
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                    </button>
                </div>
                <div class=\"navbar-collapse collapse\">
                    <ul class=\"nav navbar-nav navbar-right\">
                        {% if app.user %}
                            <li>
                                <a href=\"{{ path('article_create') }}\">
                                    Create Article
                                </a>
                            </li>
                            <li>
                                <a href=\"{{ path('user_profile') }}\">
                                    My Profile
                                </a>
                            </li>
                            <li>
                                <a href=\"{{ path('security_logout') }}\">
                                    Logout
                                </a>
                            </li>
                        {% else %}
                            <li>
                                <a href=\"{{ path('user_register') }}\">
                                    REGISTER
                                </a>
                            </li>
                            <li>
                                <a href=\"{{ path('security_login') }}\">
                                    LOGIN
                                </a>
                            </li>
                        {% endif %}
                    </ul>
                </div>
            </div>
        </div>
    </header>
{% endblock %}

<div class=\"container body-container\">
    {% block body %}
        <div class=\"row\">
            <div id=\"main\" class=\"col-sm-9\">
                {% block main %}{% endblock %}
            </div>
        </div>
    {% endblock %}
</div>

{% block footer %}
    <footer>
        <div class=\"container modal-footer\">
            <p>&copy; 2016 - Software University Foundation</p>
        </div>
    </footer>
{% endblock %}

{% block javascripts %}
    <script src=\"{{ asset('js/jquery-2.2.4.min.js') }}\"></script>
    <script src=\"{{ asset('js/moment.min.js') }}\"></script>
    <script src=\"{{ asset('js/bootstrap.js') }}\"></script>
    <script src=\"{{ asset('js/bootstrap-datetimepicker.min.js') }}\"></script>
{% endblock %}

</body>
</html>
", "base.html.twig", "C:\\xampp\\htdocs\\PHPWeb\\Blog\\app\\Resources\\views\\base.html.twig");
    }
}
