<?php

/* article/edit.html.twig */
class __TwigTemplate_ec0d69f42331c60ff29db2789e5e97da69a662cd3ac3b44e081b8a840e65a6e6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "article/edit.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1b2423927cc1f78f5d924626af48ae40ba2aa76d6b164de8716c002c636b5936 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1b2423927cc1f78f5d924626af48ae40ba2aa76d6b164de8716c002c636b5936->enter($__internal_1b2423927cc1f78f5d924626af48ae40ba2aa76d6b164de8716c002c636b5936_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "article/edit.html.twig"));

        $__internal_ea3186e5d5845b6d59a3cd88bf14d1674129b9c7a84e393109a59a1bcb03c5fe = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ea3186e5d5845b6d59a3cd88bf14d1674129b9c7a84e393109a59a1bcb03c5fe->enter($__internal_ea3186e5d5845b6d59a3cd88bf14d1674129b9c7a84e393109a59a1bcb03c5fe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "article/edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_1b2423927cc1f78f5d924626af48ae40ba2aa76d6b164de8716c002c636b5936->leave($__internal_1b2423927cc1f78f5d924626af48ae40ba2aa76d6b164de8716c002c636b5936_prof);

        
        $__internal_ea3186e5d5845b6d59a3cd88bf14d1674129b9c7a84e393109a59a1bcb03c5fe->leave($__internal_ea3186e5d5845b6d59a3cd88bf14d1674129b9c7a84e393109a59a1bcb03c5fe_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_f74cafebb7bafa278da4680637ca1b54d85dba93dae72f4f624282b10ccb8a33 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f74cafebb7bafa278da4680637ca1b54d85dba93dae72f4f624282b10ccb8a33->enter($__internal_f74cafebb7bafa278da4680637ca1b54d85dba93dae72f4f624282b10ccb8a33_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_3a6b2e0a074a4f9e8ac2a1110000ff78efb446766ad0af658c86e15b15faf444 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3a6b2e0a074a4f9e8ac2a1110000ff78efb446766ad0af658c86e15b15faf444->enter($__internal_3a6b2e0a074a4f9e8ac2a1110000ff78efb446766ad0af658c86e15b15faf444_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "    <div class=\"container body-content span=8 offset=2\">
        <div class=\"well\">
            <form class=\"form-horizontal\" action=\"";
        // line 6
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("article_edit", array("id" => $this->getAttribute(($context["article"] ?? $this->getContext($context, "article")), "id", array()))), "html", null, true);
        echo "\" method=\"POST\">
                <fieldset>
                    <legend>Edit Post</legend>

                    <div class=\"form-group\">
                        <label class=\"col-sm-4 control-label\" for=\"article_title\">Post Title</label>
                        <div class=\"col-sm-4 \">
                            <input type=\"text\" class=\"form-control\" id=\"article_title\" placeholder=\"Post Title\"
                                   name=\"article[title]\" value=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->getAttribute(($context["article"] ?? $this->getContext($context, "article")), "title", array()), "html", null, true);
        echo "\">
                        </div>
                    </div>

                    <div class=\"form-group\">
                        <label class=\"col-sm-4 control-label\" for=\"article_content\">Content</label>
                        <div class=\"col-sm-6\">
                        <textarea class=\"form-control\" rows=\"6\" id=\"article_content\"
                                  name=\"article[content]\">";
        // line 22
        echo twig_escape_filter($this->env, $this->getAttribute(($context["article"] ?? $this->getContext($context, "article")), "content", array()), "html", null, true);
        echo "</textarea>
                        </div>
                    </div>

                    ";
        // line 26
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "_token", array()), 'row');
        echo "

                    <div class=\"form-group\">
                        <div class=\"col-sm-4 col-sm-offset-4\">
                            <a class=\"btn btn-default\" href=\"";
        // line 30
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("article_view", array("id" => $this->getAttribute(($context["article"] ?? $this->getContext($context, "article")), "id", array()))), "html", null, true);
        echo "\">Cancel</a>
                            <button type=\"submit\" class=\"btn btn-success\">Edit</button>
                        </div>
                    </div>
                </fieldset>
            </form>
        </div>
    </div>
";
        
        $__internal_3a6b2e0a074a4f9e8ac2a1110000ff78efb446766ad0af658c86e15b15faf444->leave($__internal_3a6b2e0a074a4f9e8ac2a1110000ff78efb446766ad0af658c86e15b15faf444_prof);

        
        $__internal_f74cafebb7bafa278da4680637ca1b54d85dba93dae72f4f624282b10ccb8a33->leave($__internal_f74cafebb7bafa278da4680637ca1b54d85dba93dae72f4f624282b10ccb8a33_prof);

    }

    public function getTemplateName()
    {
        return "article/edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  89 => 30,  82 => 26,  75 => 22,  64 => 14,  53 => 6,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block main %}
    <div class=\"container body-content span=8 offset=2\">
        <div class=\"well\">
            <form class=\"form-horizontal\" action=\"{{ path('article_edit', {id: article.id}) }}\" method=\"POST\">
                <fieldset>
                    <legend>Edit Post</legend>

                    <div class=\"form-group\">
                        <label class=\"col-sm-4 control-label\" for=\"article_title\">Post Title</label>
                        <div class=\"col-sm-4 \">
                            <input type=\"text\" class=\"form-control\" id=\"article_title\" placeholder=\"Post Title\"
                                   name=\"article[title]\" value=\"{{ article.title }}\">
                        </div>
                    </div>

                    <div class=\"form-group\">
                        <label class=\"col-sm-4 control-label\" for=\"article_content\">Content</label>
                        <div class=\"col-sm-6\">
                        <textarea class=\"form-control\" rows=\"6\" id=\"article_content\"
                                  name=\"article[content]\">{{ article.content }}</textarea>
                        </div>
                    </div>

                    {{ form_row(form._token) }}

                    <div class=\"form-group\">
                        <div class=\"col-sm-4 col-sm-offset-4\">
                            <a class=\"btn btn-default\" href=\"{{ path('article_view', {id: article.id}) }}\">Cancel</a>
                            <button type=\"submit\" class=\"btn btn-success\">Edit</button>
                        </div>
                    </div>
                </fieldset>
            </form>
        </div>
    </div>
{% endblock %}", "article/edit.html.twig", "C:\\xampp\\htdocs\\PHPWeb\\Blog\\app\\Resources\\views\\article\\edit.html.twig");
    }
}
