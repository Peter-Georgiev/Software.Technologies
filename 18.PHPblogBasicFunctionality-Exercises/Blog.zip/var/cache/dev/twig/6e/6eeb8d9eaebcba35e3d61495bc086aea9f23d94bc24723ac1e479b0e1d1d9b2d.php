<?php

/* @WebProfiler/Collector/exception.css.twig */
class __TwigTemplate_d3dea215dd01b6b4596cbc116f79c2e9435c00740ea6d00fe4ab4033acd502f2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e6d144ba6a4f4053bbb867ad5c6885d468507b01b19ca60d32da1545103f291a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e6d144ba6a4f4053bbb867ad5c6885d468507b01b19ca60d32da1545103f291a->enter($__internal_e6d144ba6a4f4053bbb867ad5c6885d468507b01b19ca60d32da1545103f291a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.css.twig"));

        $__internal_b1f3a8472edbbbc5bb7b2397683868ce7ca3412a435cbe30d2e40ad90ab2eb65 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b1f3a8472edbbbc5bb7b2397683868ce7ca3412a435cbe30d2e40ad90ab2eb65->enter($__internal_b1f3a8472edbbbc5bb7b2397683868ce7ca3412a435cbe30d2e40ad90ab2eb65_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.css.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/exception.css.twig");
        echo "

.container {
    max-width: auto;
    margin: 0;
    padding: 0;
}
.container .container {
    padding: 0;
}

.exception-summary {
    background: #FFF;
    border: 1px solid #E0E0E0;
    box-shadow: 0 0 1px rgba(128, 128, 128, .2);
    margin: 1em 0;
    padding: 10px;
}
.exception-summary.exception-without-message {
    display: none;
}

.exception-message {
    color: #B0413E;
}

.exception-metadata,
.exception-illustration {
    display: none;
}

.exception-message-wrapper .container {
    min-height: auto;
}
";
        
        $__internal_e6d144ba6a4f4053bbb867ad5c6885d468507b01b19ca60d32da1545103f291a->leave($__internal_e6d144ba6a4f4053bbb867ad5c6885d468507b01b19ca60d32da1545103f291a_prof);

        
        $__internal_b1f3a8472edbbbc5bb7b2397683868ce7ca3412a435cbe30d2e40ad90ab2eb65->leave($__internal_b1f3a8472edbbbc5bb7b2397683868ce7ca3412a435cbe30d2e40ad90ab2eb65_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/exception.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/exception.css.twig') }}

.container {
    max-width: auto;
    margin: 0;
    padding: 0;
}
.container .container {
    padding: 0;
}

.exception-summary {
    background: #FFF;
    border: 1px solid #E0E0E0;
    box-shadow: 0 0 1px rgba(128, 128, 128, .2);
    margin: 1em 0;
    padding: 10px;
}
.exception-summary.exception-without-message {
    display: none;
}

.exception-message {
    color: #B0413E;
}

.exception-metadata,
.exception-illustration {
    display: none;
}

.exception-message-wrapper .container {
    min-height: auto;
}
", "@WebProfiler/Collector/exception.css.twig", "C:\\xampp\\htdocs\\PHPWeb\\Blog\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\exception.css.twig");
    }
}
