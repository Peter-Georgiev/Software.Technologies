<?php

/* blog/index.html.twig */
class __TwigTemplate_0969fb6bb98f7ea5bad61bf0873b38e160d63fbcdacfc52e35a07679fce5fccd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "blog/index.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3bb022f6a7ed0799ea2ed1cd9c6f4d4a2c28c023432c1499844df69defe271aa = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3bb022f6a7ed0799ea2ed1cd9c6f4d4a2c28c023432c1499844df69defe271aa->enter($__internal_3bb022f6a7ed0799ea2ed1cd9c6f4d4a2c28c023432c1499844df69defe271aa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "blog/index.html.twig"));

        $__internal_3ee441482e63a09f0ed5e7f5e46fad06c70ec76646354aadf54bfc3161510e75 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3ee441482e63a09f0ed5e7f5e46fad06c70ec76646354aadf54bfc3161510e75->enter($__internal_3ee441482e63a09f0ed5e7f5e46fad06c70ec76646354aadf54bfc3161510e75_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "blog/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_3bb022f6a7ed0799ea2ed1cd9c6f4d4a2c28c023432c1499844df69defe271aa->leave($__internal_3bb022f6a7ed0799ea2ed1cd9c6f4d4a2c28c023432c1499844df69defe271aa_prof);

        
        $__internal_3ee441482e63a09f0ed5e7f5e46fad06c70ec76646354aadf54bfc3161510e75->leave($__internal_3ee441482e63a09f0ed5e7f5e46fad06c70ec76646354aadf54bfc3161510e75_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_38ec7dd46a62444210a45df120bcbb8e89dd27088d7d6c7ece3c68c8e5b176a0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_38ec7dd46a62444210a45df120bcbb8e89dd27088d7d6c7ece3c68c8e5b176a0->enter($__internal_38ec7dd46a62444210a45df120bcbb8e89dd27088d7d6c7ece3c68c8e5b176a0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_eb2a83d80656e0056607de944f7add435ea9a289241dabc3e35853a4038b348f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_eb2a83d80656e0056607de944f7add435ea9a289241dabc3e35853a4038b348f->enter($__internal_eb2a83d80656e0056607de944f7add435ea9a289241dabc3e35853a4038b348f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "    <div class=\"container body-content\">
        <div class=\"row\">
            ";
        // line 6
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["articles"] ?? $this->getContext($context, "articles")));
        foreach ($context['_seq'] as $context["_key"] => $context["article"]) {
            // line 7
            echo "                <div class=\"col-md-6\">
                    <article>
                        <header>
                            <h2>";
            // line 10
            echo twig_escape_filter($this->env, $this->getAttribute($context["article"], "title", array()), "html", null, true);
            echo "</h2>
                        </header>

                        <p>
                            ";
            // line 14
            echo twig_escape_filter($this->env, $this->getAttribute($context["article"], "summary", array()), "html", null, true);
            echo "
                        </p>

                        <small class=\"author\">
                            ";
            // line 18
            echo twig_escape_filter($this->env, $this->getAttribute($context["article"], "author", array()), "html", null, true);
            echo "
                        </small>

                        <footer>
                            <div class=\"pull-right\">
                                <a class=\"btn btn-default btn-xs\"
                                   href=\"";
            // line 24
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("article_view", array("id" => $this->getAttribute($context["article"], "id", array()))), "html", null, true);
            echo "\">Read more &raquo;</a>
                            </div>
                        </footer>
                    </article>
                </div>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['article'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 30
        echo "        </div>
    </div>
";
        
        $__internal_eb2a83d80656e0056607de944f7add435ea9a289241dabc3e35853a4038b348f->leave($__internal_eb2a83d80656e0056607de944f7add435ea9a289241dabc3e35853a4038b348f_prof);

        
        $__internal_38ec7dd46a62444210a45df120bcbb8e89dd27088d7d6c7ece3c68c8e5b176a0->leave($__internal_38ec7dd46a62444210a45df120bcbb8e89dd27088d7d6c7ece3c68c8e5b176a0_prof);

    }

    public function getTemplateName()
    {
        return "blog/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  97 => 30,  85 => 24,  76 => 18,  69 => 14,  62 => 10,  57 => 7,  53 => 6,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block main %}
    <div class=\"container body-content\">
        <div class=\"row\">
            {% for article in articles %}
                <div class=\"col-md-6\">
                    <article>
                        <header>
                            <h2>{{ article.title }}</h2>
                        </header>

                        <p>
                            {{ article.summary }}
                        </p>

                        <small class=\"author\">
                            {{ article.author }}
                        </small>

                        <footer>
                            <div class=\"pull-right\">
                                <a class=\"btn btn-default btn-xs\"
                                   href=\"{{ path('article_view', {'id' : article.id}) }}\">Read more &raquo;</a>
                            </div>
                        </footer>
                    </article>
                </div>
            {% endfor %}
        </div>
    </div>
{% endblock %}
", "blog/index.html.twig", "C:\\xampp\\htdocs\\PHPWeb\\Blog\\app\\Resources\\views\\blog\\index.html.twig");
    }
}
