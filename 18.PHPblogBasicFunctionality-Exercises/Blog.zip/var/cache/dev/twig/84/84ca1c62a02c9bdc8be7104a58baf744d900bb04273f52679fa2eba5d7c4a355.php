<?php

/* security/login.html.twig */
class __TwigTemplate_6d4ab66d871a00d548fd2bf2acd4b744b43c8a99f5e2d5893c8a7b621307ae2b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "security/login.html.twig", 1);
        $this->blocks = array(
            'body_id' => array($this, 'block_body_id'),
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_807f82a04ab9770bacb9f8173c87c6d31af6b1f417bd2b266c6c94c8fa0ff981 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_807f82a04ab9770bacb9f8173c87c6d31af6b1f417bd2b266c6c94c8fa0ff981->enter($__internal_807f82a04ab9770bacb9f8173c87c6d31af6b1f417bd2b266c6c94c8fa0ff981_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "security/login.html.twig"));

        $__internal_5a522b0fa05ebe6bc6e903922d3ae68aa701ebecb899dfa9ab9339a907dc3f2b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5a522b0fa05ebe6bc6e903922d3ae68aa701ebecb899dfa9ab9339a907dc3f2b->enter($__internal_5a522b0fa05ebe6bc6e903922d3ae68aa701ebecb899dfa9ab9339a907dc3f2b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "security/login.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_807f82a04ab9770bacb9f8173c87c6d31af6b1f417bd2b266c6c94c8fa0ff981->leave($__internal_807f82a04ab9770bacb9f8173c87c6d31af6b1f417bd2b266c6c94c8fa0ff981_prof);

        
        $__internal_5a522b0fa05ebe6bc6e903922d3ae68aa701ebecb899dfa9ab9339a907dc3f2b->leave($__internal_5a522b0fa05ebe6bc6e903922d3ae68aa701ebecb899dfa9ab9339a907dc3f2b_prof);

    }

    // line 3
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_012be68311ae4e75b5214e5ea53d9112653f48e4880001cc48ab2a3fb44f4e18 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_012be68311ae4e75b5214e5ea53d9112653f48e4880001cc48ab2a3fb44f4e18->enter($__internal_012be68311ae4e75b5214e5ea53d9112653f48e4880001cc48ab2a3fb44f4e18_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        $__internal_ad209026d8e00a76d9b645489f6cff0bfc984fb2511c5a3e23190d5c093e08dc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ad209026d8e00a76d9b645489f6cff0bfc984fb2511c5a3e23190d5c093e08dc->enter($__internal_ad209026d8e00a76d9b645489f6cff0bfc984fb2511c5a3e23190d5c093e08dc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        echo "login";
        
        $__internal_ad209026d8e00a76d9b645489f6cff0bfc984fb2511c5a3e23190d5c093e08dc->leave($__internal_ad209026d8e00a76d9b645489f6cff0bfc984fb2511c5a3e23190d5c093e08dc_prof);

        
        $__internal_012be68311ae4e75b5214e5ea53d9112653f48e4880001cc48ab2a3fb44f4e18->leave($__internal_012be68311ae4e75b5214e5ea53d9112653f48e4880001cc48ab2a3fb44f4e18_prof);

    }

    // line 5
    public function block_main($context, array $blocks = array())
    {
        $__internal_7daeca8d70ce470fccdf06c50b9b6dff80b0c381523a4f800113ff4dbc30fbd4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7daeca8d70ce470fccdf06c50b9b6dff80b0c381523a4f800113ff4dbc30fbd4->enter($__internal_7daeca8d70ce470fccdf06c50b9b6dff80b0c381523a4f800113ff4dbc30fbd4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_076255d2530a9a024fe42cd2d01fdcefcc14f5d061fab101e23414789e51a802 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_076255d2530a9a024fe42cd2d01fdcefcc14f5d061fab101e23414789e51a802->enter($__internal_076255d2530a9a024fe42cd2d01fdcefcc14f5d061fab101e23414789e51a802_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 6
        echo "
    <div class=\"container body-content span=8 offset=2\">
        <div class=\"well\">
            <form class=\"form-horizontal\" action=\"";
        // line 9
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("security_login");
        echo "\" method=\"post\">
                <fieldset>
                    <legend>Login</legend>
                    <div class=\"form-group\">
                        <label class=\"col-sm-4 control-label\" for=\"user_email\">Email</label>
                        <div class=\"col-sm-4 \">
                            <input type=\"email\" class=\"form-control\" id=\"user_email\" placeholder=\"Email\" name=\"_username\">
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <label class=\"col-sm-4 control-label\" for=\"password\">Password</label>
                        <div class=\"col-sm-4\">
                            <input type=\"password\" class=\"form-control\" id=\"password\" placeholder=\"Password\" name=\"_password\">
                        </div>
                    </div>
                    <input type=\"hidden\" name=\"_csrf_token\" value=\"";
        // line 24
        echo twig_escape_filter($this->env, $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderCsrfToken("authenticate"), "html", null, true);
        echo "\"/>
                    <div class=\"form-group\">
                        <div class=\"col-sm-4 col-sm-offset-4\">
                            <a class=\"btn btn-default\" href=\"";
        // line 27
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("blog_index");
        echo "\">Cancel</a>
                            <button type=\"submit\" class=\"btn btn-primary\">Login</button>
                        </div>
                    </div>

                </fieldset>
            </form>
        </div>
    </div>
";
        
        $__internal_076255d2530a9a024fe42cd2d01fdcefcc14f5d061fab101e23414789e51a802->leave($__internal_076255d2530a9a024fe42cd2d01fdcefcc14f5d061fab101e23414789e51a802_prof);

        
        $__internal_7daeca8d70ce470fccdf06c50b9b6dff80b0c381523a4f800113ff4dbc30fbd4->leave($__internal_7daeca8d70ce470fccdf06c50b9b6dff80b0c381523a4f800113ff4dbc30fbd4_prof);

    }

    public function getTemplateName()
    {
        return "security/login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  97 => 27,  91 => 24,  73 => 9,  68 => 6,  59 => 5,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body_id 'login' %}

{% block main %}

    <div class=\"container body-content span=8 offset=2\">
        <div class=\"well\">
            <form class=\"form-horizontal\" action=\"{{ path('security_login') }}\" method=\"post\">
                <fieldset>
                    <legend>Login</legend>
                    <div class=\"form-group\">
                        <label class=\"col-sm-4 control-label\" for=\"user_email\">Email</label>
                        <div class=\"col-sm-4 \">
                            <input type=\"email\" class=\"form-control\" id=\"user_email\" placeholder=\"Email\" name=\"_username\">
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <label class=\"col-sm-4 control-label\" for=\"password\">Password</label>
                        <div class=\"col-sm-4\">
                            <input type=\"password\" class=\"form-control\" id=\"password\" placeholder=\"Password\" name=\"_password\">
                        </div>
                    </div>
                    <input type=\"hidden\" name=\"_csrf_token\" value=\"{{ csrf_token('authenticate') }}\"/>
                    <div class=\"form-group\">
                        <div class=\"col-sm-4 col-sm-offset-4\">
                            <a class=\"btn btn-default\" href=\"{{ path('blog_index') }}\">Cancel</a>
                            <button type=\"submit\" class=\"btn btn-primary\">Login</button>
                        </div>
                    </div>

                </fieldset>
            </form>
        </div>
    </div>
{% endblock %}
", "security/login.html.twig", "C:\\xampp\\htdocs\\PHPWeb\\Blog\\app\\Resources\\views\\security\\login.html.twig");
    }
}
