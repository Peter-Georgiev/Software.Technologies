<?php

/* user/register.html.twig */
class __TwigTemplate_f3132de16753b80de679d81ad6e248e1a9f7c675016649c6bd378b77f65b6f7c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "user/register.html.twig", 1);
        $this->blocks = array(
            'body_id' => array($this, 'block_body_id'),
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_702fc7dfb60fbcb8d99aa8b7e438a6330603797e1fdac2a8426918b91d47cb15 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_702fc7dfb60fbcb8d99aa8b7e438a6330603797e1fdac2a8426918b91d47cb15->enter($__internal_702fc7dfb60fbcb8d99aa8b7e438a6330603797e1fdac2a8426918b91d47cb15_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "user/register.html.twig"));

        $__internal_0551ebe54d3836c6dc7041896e28d8064a1c589d987341b881cbda1316093721 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0551ebe54d3836c6dc7041896e28d8064a1c589d987341b881cbda1316093721->enter($__internal_0551ebe54d3836c6dc7041896e28d8064a1c589d987341b881cbda1316093721_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "user/register.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_702fc7dfb60fbcb8d99aa8b7e438a6330603797e1fdac2a8426918b91d47cb15->leave($__internal_702fc7dfb60fbcb8d99aa8b7e438a6330603797e1fdac2a8426918b91d47cb15_prof);

        
        $__internal_0551ebe54d3836c6dc7041896e28d8064a1c589d987341b881cbda1316093721->leave($__internal_0551ebe54d3836c6dc7041896e28d8064a1c589d987341b881cbda1316093721_prof);

    }

    // line 3
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_d7d0afa80892abcd52a43cf09b1ddecd782ee81e0b3a53cd4f154ddc6497e67f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d7d0afa80892abcd52a43cf09b1ddecd782ee81e0b3a53cd4f154ddc6497e67f->enter($__internal_d7d0afa80892abcd52a43cf09b1ddecd782ee81e0b3a53cd4f154ddc6497e67f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        $__internal_66b171561150b4e4d32465d22b4916b7c33540f3fd02d3535912f3174b30f335 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_66b171561150b4e4d32465d22b4916b7c33540f3fd02d3535912f3174b30f335->enter($__internal_66b171561150b4e4d32465d22b4916b7c33540f3fd02d3535912f3174b30f335_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        echo "register";
        
        $__internal_66b171561150b4e4d32465d22b4916b7c33540f3fd02d3535912f3174b30f335->leave($__internal_66b171561150b4e4d32465d22b4916b7c33540f3fd02d3535912f3174b30f335_prof);

        
        $__internal_d7d0afa80892abcd52a43cf09b1ddecd782ee81e0b3a53cd4f154ddc6497e67f->leave($__internal_d7d0afa80892abcd52a43cf09b1ddecd782ee81e0b3a53cd4f154ddc6497e67f_prof);

    }

    // line 5
    public function block_main($context, array $blocks = array())
    {
        $__internal_f52f5bbde4c32afecd6520489146906886578cfd52dd6f13ba4e6f8b1574d753 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f52f5bbde4c32afecd6520489146906886578cfd52dd6f13ba4e6f8b1574d753->enter($__internal_f52f5bbde4c32afecd6520489146906886578cfd52dd6f13ba4e6f8b1574d753_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_5e6bdddd6c5a77ffbcd5af04901d7e17e559050af90a2e2887fee47223a919ab = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5e6bdddd6c5a77ffbcd5af04901d7e17e559050af90a2e2887fee47223a919ab->enter($__internal_5e6bdddd6c5a77ffbcd5af04901d7e17e559050af90a2e2887fee47223a919ab_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 6
        echo "    <div class=\"container body-content span=8 offset=2\">
        <div class=\"well\">
            <form class=\"form-horizontal\" action=\"";
        // line 8
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("user_register");
        echo "\" method=\"post\">
                <fieldset>
                    <legend>Login</legend>
                    <div class=\"form-group\">
                        <label class=\"col-sm-4 control-label\" for=\"user_email\">Email</label>
                        <div class=\"col-sm-4 \">
                            <input class=\"form-control\" id=\"user_email\" placeholder=\"Email\" name=\"user[email]\" required type=\"email\">
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <label class=\"col-sm-4 control-label\" for=\"user_fullName\">Full Name</label>
                        <div class=\"col-sm-4 \">
                            <input type=\"text\" class=\"form-control\" id=\"user_fullName\" placeholder=\"Full Name\" name=\"user[fullName]\" required>
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <label class=\"col-sm-4 control-label\" for=\"user_password_first\">Password</label>
                        <div class=\"col-sm-4\">
                            <input type=\"password\" class=\"form-control\" id=\"user_password_first\" placeholder=\"Password\" name=\"user[password][first]\" required>
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <label class=\"col-sm-4 control-label\" for=\"user_password_second\">Confirm Password</label>
                        <div class=\"col-sm-4\">
                            <input type=\"password\" class=\"form-control\" id=\"user_password_second\" placeholder=\"Password\" name=\"user[password][second]\" required>
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <div class=\"col-sm-4 col-sm-offset-4\">
                            <a class=\"btn btn-default\" href=\"";
        // line 37
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("blog_index");
        echo "\">Cancel</a>
                            <button type=\"submit\" class=\"btn btn-primary\">Submit</button>
                        </div>
                    </div>

                    ";
        // line 42
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "_token", array()), 'row');
        echo "
                </fieldset>
            </form>
        </div>
    </div>
";
        
        $__internal_5e6bdddd6c5a77ffbcd5af04901d7e17e559050af90a2e2887fee47223a919ab->leave($__internal_5e6bdddd6c5a77ffbcd5af04901d7e17e559050af90a2e2887fee47223a919ab_prof);

        
        $__internal_f52f5bbde4c32afecd6520489146906886578cfd52dd6f13ba4e6f8b1574d753->leave($__internal_f52f5bbde4c32afecd6520489146906886578cfd52dd6f13ba4e6f8b1574d753_prof);

    }

    public function getTemplateName()
    {
        return "user/register.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  112 => 42,  104 => 37,  72 => 8,  68 => 6,  59 => 5,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body_id 'register' %}

{% block main %}
    <div class=\"container body-content span=8 offset=2\">
        <div class=\"well\">
            <form class=\"form-horizontal\" action=\"{{ path('user_register') }}\" method=\"post\">
                <fieldset>
                    <legend>Login</legend>
                    <div class=\"form-group\">
                        <label class=\"col-sm-4 control-label\" for=\"user_email\">Email</label>
                        <div class=\"col-sm-4 \">
                            <input class=\"form-control\" id=\"user_email\" placeholder=\"Email\" name=\"user[email]\" required type=\"email\">
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <label class=\"col-sm-4 control-label\" for=\"user_fullName\">Full Name</label>
                        <div class=\"col-sm-4 \">
                            <input type=\"text\" class=\"form-control\" id=\"user_fullName\" placeholder=\"Full Name\" name=\"user[fullName]\" required>
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <label class=\"col-sm-4 control-label\" for=\"user_password_first\">Password</label>
                        <div class=\"col-sm-4\">
                            <input type=\"password\" class=\"form-control\" id=\"user_password_first\" placeholder=\"Password\" name=\"user[password][first]\" required>
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <label class=\"col-sm-4 control-label\" for=\"user_password_second\">Confirm Password</label>
                        <div class=\"col-sm-4\">
                            <input type=\"password\" class=\"form-control\" id=\"user_password_second\" placeholder=\"Password\" name=\"user[password][second]\" required>
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <div class=\"col-sm-4 col-sm-offset-4\">
                            <a class=\"btn btn-default\" href=\"{{ path('blog_index') }}\">Cancel</a>
                            <button type=\"submit\" class=\"btn btn-primary\">Submit</button>
                        </div>
                    </div>

                    {{  form_row(form._token) }}
                </fieldset>
            </form>
        </div>
    </div>
{% endblock %}
", "user/register.html.twig", "C:\\xampp\\htdocs\\PHPWeb\\Blog\\app\\Resources\\views\\user\\register.html.twig");
    }
}
