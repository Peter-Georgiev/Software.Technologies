<?php

/* user/profile.html.twig */
class __TwigTemplate_5e802f08b1bcacd7f5f29286e8ba3f578efbb1f1615eeb691f8384f3bb7db8ca extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "user/profile.html.twig", 1);
        $this->blocks = array(
            'body_id' => array($this, 'block_body_id'),
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d5fe56409d04403306ea75b90d5484c19e70a50247dcf7404f630aa8fcae30b5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d5fe56409d04403306ea75b90d5484c19e70a50247dcf7404f630aa8fcae30b5->enter($__internal_d5fe56409d04403306ea75b90d5484c19e70a50247dcf7404f630aa8fcae30b5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "user/profile.html.twig"));

        $__internal_a84d76ca62b62d49c321a211ab6d69b927ac88f3a4a9a0c88b1d8e8044f09971 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a84d76ca62b62d49c321a211ab6d69b927ac88f3a4a9a0c88b1d8e8044f09971->enter($__internal_a84d76ca62b62d49c321a211ab6d69b927ac88f3a4a9a0c88b1d8e8044f09971_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "user/profile.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_d5fe56409d04403306ea75b90d5484c19e70a50247dcf7404f630aa8fcae30b5->leave($__internal_d5fe56409d04403306ea75b90d5484c19e70a50247dcf7404f630aa8fcae30b5_prof);

        
        $__internal_a84d76ca62b62d49c321a211ab6d69b927ac88f3a4a9a0c88b1d8e8044f09971->leave($__internal_a84d76ca62b62d49c321a211ab6d69b927ac88f3a4a9a0c88b1d8e8044f09971_prof);

    }

    // line 3
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_d95a4469fdbcf74f290e709b0adacb0da93732a0a6ab0f2a39f21e911dc78dcd = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d95a4469fdbcf74f290e709b0adacb0da93732a0a6ab0f2a39f21e911dc78dcd->enter($__internal_d95a4469fdbcf74f290e709b0adacb0da93732a0a6ab0f2a39f21e911dc78dcd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        $__internal_dd8a90ae2b7027f5970f9ffc32e8a10cb11278343bd61ad94aa4e8dbb224e07e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_dd8a90ae2b7027f5970f9ffc32e8a10cb11278343bd61ad94aa4e8dbb224e07e->enter($__internal_dd8a90ae2b7027f5970f9ffc32e8a10cb11278343bd61ad94aa4e8dbb224e07e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        echo "profile";
        
        $__internal_dd8a90ae2b7027f5970f9ffc32e8a10cb11278343bd61ad94aa4e8dbb224e07e->leave($__internal_dd8a90ae2b7027f5970f9ffc32e8a10cb11278343bd61ad94aa4e8dbb224e07e_prof);

        
        $__internal_d95a4469fdbcf74f290e709b0adacb0da93732a0a6ab0f2a39f21e911dc78dcd->leave($__internal_d95a4469fdbcf74f290e709b0adacb0da93732a0a6ab0f2a39f21e911dc78dcd_prof);

    }

    // line 5
    public function block_main($context, array $blocks = array())
    {
        $__internal_449924d08a7b9530534f82cdbcf245588cf4ffc16d0cbf9d07ce1d2676fab710 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_449924d08a7b9530534f82cdbcf245588cf4ffc16d0cbf9d07ce1d2676fab710->enter($__internal_449924d08a7b9530534f82cdbcf245588cf4ffc16d0cbf9d07ce1d2676fab710_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_9efe5850a3880a71d88ab9379666833087ec0acb5597bf0bcaced28de0fb07b3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9efe5850a3880a71d88ab9379666833087ec0acb5597bf0bcaced28de0fb07b3->enter($__internal_9efe5850a3880a71d88ab9379666833087ec0acb5597bf0bcaced28de0fb07b3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 6
        echo "    <div>
        ";
        // line 7
        echo twig_escape_filter($this->env, $this->getAttribute(($context["user"] ?? $this->getContext($context, "user")), "email", array()), "html", null, true);
        echo "
        <br>
        ";
        // line 9
        echo twig_escape_filter($this->env, $this->getAttribute(($context["user"] ?? $this->getContext($context, "user")), "fullName", array()), "html", null, true);
        echo "
    </div>
";
        
        $__internal_9efe5850a3880a71d88ab9379666833087ec0acb5597bf0bcaced28de0fb07b3->leave($__internal_9efe5850a3880a71d88ab9379666833087ec0acb5597bf0bcaced28de0fb07b3_prof);

        
        $__internal_449924d08a7b9530534f82cdbcf245588cf4ffc16d0cbf9d07ce1d2676fab710->leave($__internal_449924d08a7b9530534f82cdbcf245588cf4ffc16d0cbf9d07ce1d2676fab710_prof);

    }

    public function getTemplateName()
    {
        return "user/profile.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  76 => 9,  71 => 7,  68 => 6,  59 => 5,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body_id 'profile' %}

{% block main %}
    <div>
        {{ user.email }}
        <br>
        {{ user.fullName }}
    </div>
{% endblock %}
", "user/profile.html.twig", "C:\\xampp\\htdocs\\PHPWeb\\Blog\\app\\Resources\\views\\user\\profile.html.twig");
    }
}
