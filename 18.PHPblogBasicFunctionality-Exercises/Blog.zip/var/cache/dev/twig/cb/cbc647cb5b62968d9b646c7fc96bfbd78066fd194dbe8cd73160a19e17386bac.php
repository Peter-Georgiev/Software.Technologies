<?php

/* form/fields.html.twig */
class __TwigTemplate_766fada10806aee0f86119c42dc617fed0e97b5f9a1d16cfa2cc799fd6872f87 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'date_time_picker_widget' => array($this, 'block_date_time_picker_widget'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e7d78238bf5a67b43ac145849ce31af90e46cec7c56aa0cef1ef0b81c92775ed = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e7d78238bf5a67b43ac145849ce31af90e46cec7c56aa0cef1ef0b81c92775ed->enter($__internal_e7d78238bf5a67b43ac145849ce31af90e46cec7c56aa0cef1ef0b81c92775ed_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "form/fields.html.twig"));

        $__internal_ebe78dda6a06a985734f67d2cb311b9acdaa12190eedd1b9b0de57eba53623ef = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ebe78dda6a06a985734f67d2cb311b9acdaa12190eedd1b9b0de57eba53623ef->enter($__internal_ebe78dda6a06a985734f67d2cb311b9acdaa12190eedd1b9b0de57eba53623ef_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "form/fields.html.twig"));

        // line 9
        echo "
";
        // line 10
        $this->displayBlock('date_time_picker_widget', $context, $blocks);
        
        $__internal_e7d78238bf5a67b43ac145849ce31af90e46cec7c56aa0cef1ef0b81c92775ed->leave($__internal_e7d78238bf5a67b43ac145849ce31af90e46cec7c56aa0cef1ef0b81c92775ed_prof);

        
        $__internal_ebe78dda6a06a985734f67d2cb311b9acdaa12190eedd1b9b0de57eba53623ef->leave($__internal_ebe78dda6a06a985734f67d2cb311b9acdaa12190eedd1b9b0de57eba53623ef_prof);

    }

    public function block_date_time_picker_widget($context, array $blocks = array())
    {
        $__internal_8fed60d98fc8ad2d1eb86813cebee7f44a20534aee36e3c7af4984dfaae5a89d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8fed60d98fc8ad2d1eb86813cebee7f44a20534aee36e3c7af4984dfaae5a89d->enter($__internal_8fed60d98fc8ad2d1eb86813cebee7f44a20534aee36e3c7af4984dfaae5a89d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "date_time_picker_widget"));

        $__internal_9e8c6c14080c08adb6844899c23175b5c5fb3ee118d9921b20fa15e1a74085b3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9e8c6c14080c08adb6844899c23175b5c5fb3ee118d9921b20fa15e1a74085b3->enter($__internal_9e8c6c14080c08adb6844899c23175b5c5fb3ee118d9921b20fa15e1a74085b3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "date_time_picker_widget"));

        // line 11
        echo "    ";
        ob_start();
        // line 12
        echo "        <div class=\"input-group date\" data-toggle=\"datetimepicker\">
            ";
        // line 13
        $this->displayBlock("datetime_widget", $context, $blocks);
        echo "
            ";
        // line 15
        echo "                ";
        // line 16
        echo "            ";
        // line 17
        echo "        </div>
    ";
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
        
        $__internal_9e8c6c14080c08adb6844899c23175b5c5fb3ee118d9921b20fa15e1a74085b3->leave($__internal_9e8c6c14080c08adb6844899c23175b5c5fb3ee118d9921b20fa15e1a74085b3_prof);

        
        $__internal_8fed60d98fc8ad2d1eb86813cebee7f44a20534aee36e3c7af4984dfaae5a89d->leave($__internal_8fed60d98fc8ad2d1eb86813cebee7f44a20534aee36e3c7af4984dfaae5a89d_prof);

    }

    public function getTemplateName()
    {
        return "form/fields.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  61 => 17,  59 => 16,  57 => 15,  53 => 13,  50 => 12,  47 => 11,  29 => 10,  26 => 9,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#
   Each field type is rendered by a template fragment, which is determined
   by the name of your form type class (DateTimePickerType -> date_time_picker)
   and the suffix \"_widget\". This can be controlled by overriding getBlockPrefix()
   in DateTimePickerType.

   See http://symfony.com/doc/current/cookbook/form/create_custom_field_type.html#creating-a-template-for-the-field
#}

{% block date_time_picker_widget %}
    {% spaceless %}
        <div class=\"input-group date\" data-toggle=\"datetimepicker\">
            {{ block('datetime_widget') }}
            {#<span class=\"input-group-addon\">#}
                {#<span class=\"fa fa-calendar\" aria-hidden=\"true\"></span>#}
            {#</span>#}
        </div>
    {% endspaceless %}
{% endblock %}
", "form/fields.html.twig", "C:\\xampp\\htdocs\\PHPWeb\\Blog\\app\\Resources\\views\\form\\fields.html.twig");
    }
}
