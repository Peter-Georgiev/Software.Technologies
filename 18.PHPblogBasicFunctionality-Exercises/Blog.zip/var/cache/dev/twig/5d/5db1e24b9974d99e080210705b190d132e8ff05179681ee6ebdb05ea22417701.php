<?php

/* @WebProfiler/Collector/exception.html.twig */
class __TwigTemplate_66d8cebdf353fb48fb6b95887cc3f9b673d4221fee80f34982417e3695772d01 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/exception.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_46756905d47757b54f738659021c2c194284eb017c5aa9652d03b6792cd4e306 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_46756905d47757b54f738659021c2c194284eb017c5aa9652d03b6792cd4e306->enter($__internal_46756905d47757b54f738659021c2c194284eb017c5aa9652d03b6792cd4e306_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $__internal_52935fedb28a0eee6d74d105e058c3a42cb4f23181c2852a695b0317250c1c70 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_52935fedb28a0eee6d74d105e058c3a42cb4f23181c2852a695b0317250c1c70->enter($__internal_52935fedb28a0eee6d74d105e058c3a42cb4f23181c2852a695b0317250c1c70_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_46756905d47757b54f738659021c2c194284eb017c5aa9652d03b6792cd4e306->leave($__internal_46756905d47757b54f738659021c2c194284eb017c5aa9652d03b6792cd4e306_prof);

        
        $__internal_52935fedb28a0eee6d74d105e058c3a42cb4f23181c2852a695b0317250c1c70->leave($__internal_52935fedb28a0eee6d74d105e058c3a42cb4f23181c2852a695b0317250c1c70_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_69af3697187abe92ae88389e10664626ece6de514c5275facc40678effd62ebf = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_69af3697187abe92ae88389e10664626ece6de514c5275facc40678effd62ebf->enter($__internal_69af3697187abe92ae88389e10664626ece6de514c5275facc40678effd62ebf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_a9554d032a10227e303aa689c0b69fbabe1312edd1274360f04ea0e86745dba4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a9554d032a10227e303aa689c0b69fbabe1312edd1274360f04ea0e86745dba4->enter($__internal_a9554d032a10227e303aa689c0b69fbabe1312edd1274360f04ea0e86745dba4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    ";
        if ($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 5
            echo "        <style>
            ";
            // line 6
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception_css", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
            echo "
        </style>
    ";
        }
        // line 9
        echo "    ";
        $this->displayParentBlock("head", $context, $blocks);
        echo "
";
        
        $__internal_a9554d032a10227e303aa689c0b69fbabe1312edd1274360f04ea0e86745dba4->leave($__internal_a9554d032a10227e303aa689c0b69fbabe1312edd1274360f04ea0e86745dba4_prof);

        
        $__internal_69af3697187abe92ae88389e10664626ece6de514c5275facc40678effd62ebf->leave($__internal_69af3697187abe92ae88389e10664626ece6de514c5275facc40678effd62ebf_prof);

    }

    // line 12
    public function block_menu($context, array $blocks = array())
    {
        $__internal_b406b35d2c52540e571e298eed096b7ba29da88475adbaab26eb2cf4f7b30ce8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b406b35d2c52540e571e298eed096b7ba29da88475adbaab26eb2cf4f7b30ce8->enter($__internal_b406b35d2c52540e571e298eed096b7ba29da88475adbaab26eb2cf4f7b30ce8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_f4587ac0c96c2321ae5c0a936b46a6144aa9b9870a72541f29203f1f59919edd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f4587ac0c96c2321ae5c0a936b46a6144aa9b9870a72541f29203f1f59919edd->enter($__internal_f4587ac0c96c2321ae5c0a936b46a6144aa9b9870a72541f29203f1f59919edd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 13
        echo "    <span class=\"label ";
        echo (($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) ? ("label-status-error") : ("disabled"));
        echo "\">
        <span class=\"icon\">";
        // line 14
        echo twig_include($this->env, $context, "@WebProfiler/Icon/exception.svg");
        echo "</span>
        <strong>Exception</strong>
        ";
        // line 16
        if ($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 17
            echo "            <span class=\"count\">
                <span>1</span>
            </span>
        ";
        }
        // line 21
        echo "    </span>
";
        
        $__internal_f4587ac0c96c2321ae5c0a936b46a6144aa9b9870a72541f29203f1f59919edd->leave($__internal_f4587ac0c96c2321ae5c0a936b46a6144aa9b9870a72541f29203f1f59919edd_prof);

        
        $__internal_b406b35d2c52540e571e298eed096b7ba29da88475adbaab26eb2cf4f7b30ce8->leave($__internal_b406b35d2c52540e571e298eed096b7ba29da88475adbaab26eb2cf4f7b30ce8_prof);

    }

    // line 24
    public function block_panel($context, array $blocks = array())
    {
        $__internal_89aad92231d9371c2f10837341c32dead91bfdfb2bdb1436d3fc8abfbd52b7c7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_89aad92231d9371c2f10837341c32dead91bfdfb2bdb1436d3fc8abfbd52b7c7->enter($__internal_89aad92231d9371c2f10837341c32dead91bfdfb2bdb1436d3fc8abfbd52b7c7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_5dde5c78e29dc4fc7f6eb0490ac7b8d0cc9c05d45d6860bc5c2a54722c6c4641 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5dde5c78e29dc4fc7f6eb0490ac7b8d0cc9c05d45d6860bc5c2a54722c6c4641->enter($__internal_5dde5c78e29dc4fc7f6eb0490ac7b8d0cc9c05d45d6860bc5c2a54722c6c4641_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 25
        echo "    <h2>Exceptions</h2>

    ";
        // line 27
        if ( !$this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 28
            echo "        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    ";
        } else {
            // line 32
            echo "        <div class=\"sf-reset\">
            ";
            // line 33
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
            echo "
        </div>
    ";
        }
        
        $__internal_5dde5c78e29dc4fc7f6eb0490ac7b8d0cc9c05d45d6860bc5c2a54722c6c4641->leave($__internal_5dde5c78e29dc4fc7f6eb0490ac7b8d0cc9c05d45d6860bc5c2a54722c6c4641_prof);

        
        $__internal_89aad92231d9371c2f10837341c32dead91bfdfb2bdb1436d3fc8abfbd52b7c7->leave($__internal_89aad92231d9371c2f10837341c32dead91bfdfb2bdb1436d3fc8abfbd52b7c7_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/exception.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  138 => 33,  135 => 32,  129 => 28,  127 => 27,  123 => 25,  114 => 24,  103 => 21,  97 => 17,  95 => 16,  90 => 14,  85 => 13,  76 => 12,  63 => 9,  57 => 6,  54 => 5,  51 => 4,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block head %}
    {% if collector.hasexception %}
        <style>
            {{ render(path('_profiler_exception_css', { token: token })) }}
        </style>
    {% endif %}
    {{ parent() }}
{% endblock %}

{% block menu %}
    <span class=\"label {{ collector.hasexception ? 'label-status-error' : 'disabled' }}\">
        <span class=\"icon\">{{ include('@WebProfiler/Icon/exception.svg') }}</span>
        <strong>Exception</strong>
        {% if collector.hasexception %}
            <span class=\"count\">
                <span>1</span>
            </span>
        {% endif %}
    </span>
{% endblock %}

{% block panel %}
    <h2>Exceptions</h2>

    {% if not collector.hasexception %}
        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    {% else %}
        <div class=\"sf-reset\">
            {{ render(path('_profiler_exception', { token: token })) }}
        </div>
    {% endif %}
{% endblock %}
", "@WebProfiler/Collector/exception.html.twig", "C:\\xampp\\htdocs\\PHPWeb\\Blog\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\exception.html.twig");
    }
}
